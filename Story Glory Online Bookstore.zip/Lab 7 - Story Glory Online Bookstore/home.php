<?php
session_start();
include('conn.php');

if(!isset($_SESSION['login_user'])){
  $checkAdmin = "";
  
}else{
  include('session.php');
  
}
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Story Glory</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css"/>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;600;700&display=swap" rel="stylesheet">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  </head>

  <body>
    <!--------------------------------Header-------------------------------->
    <section class="header">
      <nav>
        <a href="home.php"><img src="images/logo.png"></a>
        <div class="search_logo">
          <a href="category.php?page=1&sort=&genre=&valueToSearch="><i class="fas fa-search"> Search for a book!</i></a>
        </div>
        <ul>
          <input id="adminvalue" type="hidden" value="<?php echo $checkAdmin; ?>">
          <li id="adminbutton"><a href="admin.php"><i class="fas fa-user-cog"></i> Admin</a></li>
          <li><a href="home.php"><i class="fas fa-igloo"></i> Home</a></li>
          <li><a href="category.php?page=1&sort=&genre=&valueToSearch="><i class="fas fa-layer-group"></i> Category</a></li>
          <li><a href="wishlist.php"><i class="fab fa-gratipay"></i> My Wishlist</a></li>
          <li><a href="Shopping_Cart.php"><i class="fas fa-shopping-cart"></i> Shopping Cart</a></li>
          <li><a href="MyPurchase.php"><i class="fas fa-shopping-bag"></i> My Purchase</a></li>
          <li><a href="account.php"><i class="fas fa-user-ninja"></i> My profile</a></li>
          <li class="logout" id="logout_btn"><a href="logout.php">Log Out</a></li>
        </ul>
      </nav>

      <div class="header-content">
        <h1>Welcome To</h1>
        <h2>STORY GLORY</h2>
        <p>Providing Convenience When It Matters Most.</p>
        <div class="login_button" id="login_button">
          <a href="login.php" class="login">Login</a>
          <a href="create_account.html" class="sign-up">Sign up</a>
        </div>
      </div>

    </section>

    <!--------------------------------Titles you might be interested in-------------------------------->
    <section class="interested">
      <div class="sub-title">
        Most recent published books
      </div>
      <div class="content">
        <?php 
        $sql_query = mysqli_query($con,"SELECT * FROM `book` ORDER BY `Publication_Date` DESC LIMIT 0,5");
   
        while ($bookrow = mysqli_fetch_array($sql_query,MYSQLI_ASSOC))
        {
        ?>
        <div class="box"><a href='product.php?isbn=<?php echo $bookrow['ISBN'] ?>&'><img src='<?php echo $bookrow['Cover'] ?>' alt="Book cover"></a></div>
        <?php
        }
        ?>
      </div>
    </section>
    <!--------------------------------Footer-------------------------------->
    <section class="footer">

      <div class="footer-title">
        <h1>About us</h1>
        <p>This is what we are</p>
      </div>

      <div class="row">
          <div class="footer-col">
            <i class="fas fa-book-reader"></i>
            <h3>Value</h3>
            <p>This online bookstore is mainly about providing the best experience to customers when they visit our website as if they were in the physical bookstore, but online!<br>It provides convenience to people who still need physical books during the lockdown of the country.</p>
          </div>
          <div class="footer-col">
            <i class="fas fa-box-open"></i>
            <h3>Product</h3>
            <p>There are plenty of user-friendly features such as a handy navigation bar, shopping cart as well as help and support section.<br>Everyone is allowed to visit our website to find books they are interested in, but in order to buy them, they would have to register.<br>There will also be special discounts and promotions exclusive to members which customers could register to become one.</p>
          </div>
          <div class="footer-col">
            <i class="fas fa-truck"></i>
            <h3>Service</h3>
            <p>All purchased books will be delivered to the customers' location on time with our professional and trusted delivery service.<br>We also include 24/7 customer support to help customers with their issues!</p>
          </div>
      </div>

      <div class="footer-icon">
        <a href="https://www.facebook.com/profile.php?id=100060182020609" target="_blank"><i class="fab fa-facebook-square"></i></a>
        <a href="https://www.instagram.com/storyglory_my/" target="_blank"><i class="fab fa-instagram"></i></a>
        <p>Kindly contact us if you require any assistance.</p>
      </div>
      
    </section>
  </body>
  <script type="text/javascript" src="script.js"></script>

</html>