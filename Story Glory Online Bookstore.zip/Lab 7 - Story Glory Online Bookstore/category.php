<?php
include('conn.php');
session_start();

if (!isset($_SESSION['login_user'])){
  $checkAdmin = "";
}else{
  include('session.php');
}

$valueToSearch = $_GET['valueToSearch'];

$page = $_GET['page'];
$sortfilter = $_GET['sort'];
$genre = $_GET['genre'];

if ($page == "1") {
  $startingnumber = "0";
  $startingnumber2 = $startingnumber + 5;
  $startingnumber3 = $startingnumber2 + 5;
  $endingnumber = $startingnumber3 + 5;

}else{
  $newpage = $page - 1;
  $startingnumber = $newpage * 15;
  $startingnumber2 = $startingnumber + 5;
  $startingnumber3 = $startingnumber2 + 5;
  $endingnumber = $startingnumber3 + 5;
}

$genrequery = "WHERE `Genre` like '%$genre%'";
$secondsearchquery = "`Title` LIKE '%$valueToSearch%'";

$totalrow_result = mysqli_query($con,"SELECT count(*) FROM `book` $genrequery AND $secondsearchquery");
$totalrow = mysqli_fetch_array($totalrow_result);
$total = $totalrow[0];

if ($total == 0){
  $noresults = "No Results Found.";
}

$maximum_page = intdiv($total, 15);
$maximum_page = $maximum_page + 1;

if ($sortfilter == "alphabet") {
  $sortname = "A to Z";
  $searchquery1 = "SELECT * FROM `book` $genrequery AND $secondsearchquery ORDER BY `Title` ASC LIMIT $startingnumber,5";
  $searchquery2 = "SELECT * FROM `book` $genrequery AND $secondsearchquery ORDER BY `Title` ASC LIMIT $startingnumber2,5";
  $searchquery3 = "SELECT * FROM `book` $genrequery AND $secondsearchquery ORDER BY `Title` ASC LIMIT $startingnumber3,5";
}elseif ($sortfilter == "pricelth"){
  $sortname = "Price Low to High";
  $searchquery1 = "SELECT * FROM `book` $genrequery AND $secondsearchquery ORDER BY `Price` ASC LIMIT $startingnumber,5";
  $searchquery2 = "SELECT * FROM `book` $genrequery AND $secondsearchquery ORDER BY `Price` ASC LIMIT $startingnumber2,5";
  $searchquery3 = "SELECT * FROM `book` $genrequery AND $secondsearchquery ORDER BY `Price` ASC LIMIT $startingnumber3,5";
}elseif ($sortfilter == "pricehtl"){
  $sortname = "High to Low";
  $searchquery1 = "SELECT * FROM `book` $genrequery AND $secondsearchquery ORDER BY `Price` DESC LIMIT $startingnumber,5";
  $searchquery2 = "SELECT * FROM `book` $genrequery AND $secondsearchquery ORDER BY `Price` DESC LIMIT $startingnumber2,5";
  $searchquery3 = "SELECT * FROM `book` $genrequery AND $secondsearchquery ORDER BY `Price` DESC LIMIT $startingnumber3,5";
}elseif ($sortfilter == "recent"){
  $sortname = "Recently Published";
  $searchquery1 = "SELECT * FROM `book` $genrequery AND $secondsearchquery ORDER BY `Publication_Date` DESC LIMIT $startingnumber,5";
  $searchquery2 = "SELECT * FROM `book` $genrequery AND $secondsearchquery ORDER BY `Publication_Date` DESC LIMIT $startingnumber2,5";
  $searchquery3 = "SELECT * FROM `book` $genrequery AND $secondsearchquery ORDER BY `Publication_Date` DESC LIMIT $startingnumber3,5";
}else{
  $sortname = "";
  $searchquery1 = "SELECT * FROM `book` $genrequery AND $secondsearchquery LIMIT $startingnumber,5";
  $searchquery2 = "SELECT * FROM `book` $genrequery AND $secondsearchquery LIMIT $startingnumber2,5";
  $searchquery3 = "SELECT * FROM `book` $genrequery AND $secondsearchquery LIMIT $startingnumber3,5";
}

?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Story Glory</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css"/>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;600;700&display=swap" rel="stylesheet">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  </head>

  <body>
    <!--------------------------------Header-------------------------------->
    <section class="mini-header">

      <nav>
        <a href="home.php"><img src="images/logo.png"></a>
        <div class="search_logo">
        <a href="category.php?page=1&sort=&genre=&valueToSearch="><i class="fas fa-search"> Search for a book!</i></a>
        </div>
        <ul>
          <input id="adminvalue" type="hidden" value="<?php echo $checkAdmin; ?>">
          <li id="adminbutton"><a href="admin.php"><i class="fas fa-user-cog"></i> Admin</a></li>
          <li><a href="home.php"><i class="fas fa-igloo"></i> Home</a></li>
          <li><a href="category.php?page=1&sort=&genre=&valueToSearch="><i class="fas fa-layer-group"></i> Category</a></li>
          <li><a href="wishlist.php"><i class="fab fa-gratipay"></i> My Wishlist</a></li>
          <li><a href="Shopping_Cart.php"><i class="fas fa-shopping-cart"></i> Shopping Cart</a></li>
          <li><a href="MyPurchase.php"><i class="fas fa-shopping-bag"></i> My Purchase</a></li>
          <li><a href="account.php"><i class="fas fa-user-ninja"></i> My profile</a></li>
          <li class="logout" id="logout_btn"><a href="logout.php">Log Out</a></li>
        </ul>
      </nav>

      <h1>Categories</h1>

    </section>

    <!--------------------------------Category-------------------------------->

    <section class="search_book">
      <form method="post" name="search_form" id="search_form" action="">
        <input type="text" id="search_value" class="search_book_bar" name="valueToSearch" placeholder="Enter a book's name" value="<?php echo $valueToSearch ?>">
        <button onclick="searchbook()"><i class="fas fa-search"></i></button>
      </form>
      <div class="resetsearch">
        <a href="category.php?page=1&sort=<?php echo $sortfilter; ?>&genre=<?php echo $genre ?>&valueToSearch=">Reset Search Value</a>
      </div>
      <h3>Sorted by: <?php echo $genre ?> | <?php echo $sortname ?> | <?php echo $valueToSearch ?></h3>
    </section>

    <section class="categories">

      <span class="genre">
        <input id="genreid" type="hidden" value="<?php echo $genre; ?>">
        <h2>Genres</h2>
        <ul class="genre-list">
          <li><a href="category.php?page=1&sort=<?php echo $sortfilter; ?>&genre=Academic&valueToSearch=<?php echo $valueToSearch?>">Academic</a></li>
          <li><a href="category.php?page=1&sort=<?php echo $sortfilter; ?>&genre=Motivational&valueToSearch=<?php echo $valueToSearch?>">Motivational</a></li>
          <li><a href="category.php?page=1&sort=<?php echo $sortfilter; ?>&genre=Fantasy&valueToSearch=<?php echo $valueToSearch?>">Fantasy</a></li>
          <li><a href="category.php?page=1&sort=<?php echo $sortfilter; ?>&genre=Romance&valueToSearch=<?php echo $valueToSearch?>">Romance</a></li>
          <li><a href="category.php?page=1&sort=<?php echo $sortfilter; ?>&genre=Horror&valueToSearch=<?php echo $valueToSearch?>">Horror</a></li>
          <li><a href="category.php?page=1&sort=<?php echo $sortfilter; ?>&genre=Sci-fi&valueToSearch=<?php echo $valueToSearch?>">Sci-fi</a></li>
          <li><a href="category.php?page=1&sort=<?php echo $sortfilter; ?>&genre=History&valueToSearch=<?php echo $valueToSearch?>">History</a></li>
          <li><a href="category.php?page=1&sort=<?php echo $sortfilter; ?>&genre=Kids&valueToSearch=<?php echo $valueToSearch?>">Kids</a></li>
          <li><a href="category.php?page=1&sort=<?php echo $sortfilter; ?>&genre=&valueToSearch=<?php echo $valueToSearch?>"><strong>Reset Genre</strong></a></li>
        </ul>
      </span>

      <span class="book-listing">
        <h3>
          <?php
            if ($endingnumber >= $total){
              $endingnumber = $total;
            }
            if ($total == 0){
              $startingnumber = -1;
              $endingnumber = 0;
            }
          ?>
          <span class="results">Showing <?php echo $startingnumber + 1; ?> - <?php echo $endingnumber; ?> of <?php echo $total; ?> results</span>
          <input type="hidden" id="sortid" value="<?php echo $sortfilter; ?>">
          <span class="sortby">Sort by:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <a href="category.php?page=1&sort=alphabet&genre=<?php echo $genre; ?>&valueToSearch=<?php echo $valueToSearch?>">A-Z</a>&nbsp;|&nbsp;
            <a href="category.php?page=1&sort=pricelth&genre=<?php echo $genre; ?>&valueToSearch=<?php echo $valueToSearch?>">Price: low to high</a>&nbsp;|&nbsp;
            <a href="category.php?page=1&sort=pricehtl&genre=<?php echo $genre; ?>&valueToSearch=<?php echo $valueToSearch?>">Price: high to low</a>&nbsp;|&nbsp;
            <a href="category.php?page=1&sort=recent&genre=<?php echo $genre; ?>&valueToSearch=<?php echo $valueToSearch?>">Most recent</a>&nbsp;|&nbsp;
            <a href="category.php?page=1&sort=&genre=<?php echo $genre; ?>&valueToSearch=<?php echo $valueToSearch?>">Reset Sorting</a>&nbsp;|&nbsp;
          </span>
        </h3>

        <div class="content">
          <?php 
          $sql_query = mysqli_query($con,$searchquery1) or die(mysqli_error($con));

          while ($bookrow = mysqli_fetch_array($sql_query,MYSQLI_ASSOC))
          {
          ?>
          <span class="box"><a href='product.php?isbn=<?php echo $bookrow['ISBN'] ?>&'><img src='<?php echo $bookrow['Cover'] ?>'></a></span>
          <?php
          }
          ?>
          <br>
        </div>
        <div class="content">
          <?php 
          $sql_query = mysqli_query($con,$searchquery2) or die(mysqli_error($con));

          while ($bookrow = mysqli_fetch_array($sql_query,MYSQLI_ASSOC))
          {
          ?>
          <span class="box"><a href='product.php?isbn=<?php echo $bookrow['ISBN'] ?>&'><img src='<?php echo $bookrow['Cover'] ?>'></a></span>
          <?php
          }
          ?>
          <br>
        </div>
        <div class="content">
          <?php 
          $sql_query = mysqli_query($con,$searchquery3) or die(mysqli_error($con));

          while ($bookrow = mysqli_fetch_array($sql_query,MYSQLI_ASSOC))
          {
          ?>
          <span class="box"><a href='product.php?isbn=<?php echo $bookrow['ISBN'] ?>&'><img src='<?php echo $bookrow['Cover'] ?>'></a></span>
          <?php
          }
          ?>
          <br>
        </div>
        <?php
          mysqli_close($con);
        ?>
        
        <div class="buttons">
          <input type="hidden" id="pagecount" value="<?php echo $page ?>">
          <input type="hidden" id="maximumpage" value="<?php echo $maximum_page ?>">
          <a id="previous-page" href="category.php?page=<?php echo $page-1 ?>&sort=<?php echo $sortfilter; ?>&genre=<?php echo $genre ?>&valueToSearch=<?php echo $valueToSearch ?>"><i class="fas fa-chevron-left"></i></a>&nbsp;<?php echo $page ?>&nbsp;<a id="next-page" href="category.php?page=<?php echo $page+1 ?>&sort=<?php echo $sortfilter; ?>&genre=<?php echo $genre ?>&valueToSearch=<?php echo $valueToSearch ?>"><i class="fas fa-chevron-right"></i></a>
        </div>
      </span>
    </section>

    <!--------------------------------Footer-------------------------------->
    <section class="footer">

      <div class="footer-title">
        <h1>About us</h1>
        <p>This is what we are</p>
      </div>

      <div class="row">
          <div class="footer-col">
            <i class="fas fa-book-reader"></i>
            <h3>Value</h3>
            <p>This online bookstore is mainly about providing the best experience to customers when they visit our website as if they were in the physical bookstore, but online!<br>It provides convenience to people who still need physical books during the lockdown of the country.</p>
          </div>
          <div class="footer-col">
            <i class="fas fa-box-open"></i>
            <h3>Product</h3>
            <p>There are plenty of user-friendly features such as a handy navigation bar, shopping cart as well as help and support section.<br>Everyone is allowed to visit our website to find books they are interested in, but in order to buy them, they would have to register.<br>There will also be special discounts and promotions exclusive to members which customers could register to become one.</p>
          </div>
          <div class="footer-col">
            <i class="fas fa-truck"></i>
            <h3>Service</h3>
            <p>All purchased books will be delivered to the customers' location on time with our professional and trusted delivery service.<br>We also include 24/7 customer support to help customers with their issues!</p>
          </div>
      </div>

      <div class="footer-icon">
        <a href="https://www.facebook.com/profile.php?id=100060182020609"><i class="fab fa-facebook-square"></i></a>
        <a href="https://www.instagram.com/storyglory_my/"><i class="fab fa-instagram"></i></a>
        <p>Kindly contact us if you require any assistance.</p>
      </div>
      
    </section>
  </body>

  <script type="text/javascript" src="script.js"></script>
  <script type="text/javascript">
    var pagecount = document.getElementById("pagecount").value;
    var maxpage = document.getElementById("maximumpage").value;

    if (pagecount == 1) {
      document.getElementById("previous-page").href = "category.php?page=1&sort=<?php echo $sortfilter; ?>&genre=<?php echo $genre ?>&valueToSearch=<?php echo $valueToSearch ?>";
    }
    if (pagecount == maxpage) {
      document.getElementById("next-page").href = "category.php?page=<?php echo $maximum_page ?>&sort=<?php echo $sortfilter; ?>&genre=<?php echo $genre ?>&valueToSearch=<?php echo $valueToSearch ?>";
    }

    function searchbook() {
      var sort = document.getElementById("sortid").value;
      var genre = document.getElementById("genreid").value;
      var searchvalue = document.getElementById("search_value").value;
      var searchform = document.getElementById("search_form");
      searchform.action = `category.php?page=1&sort=${sort}&genre=${genre}&valueToSearch=${searchvalue}`;
      searchform.submit();

    }
  </script>

</html>