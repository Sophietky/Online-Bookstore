<?php
include('session.php');
include('conn.php');

$total_price_shipping = $_POST['total_price_hidden'];
$deliver_type = $_POST['deliver_type'];

//get book title and Subtotal
$cart_query = "SELECT shopping_cart_item.Subtotal, book.Title FROM book
INNER JOIN shopping_cart_item ON book.ISBN = shopping_cart_item.Book_ID
INNER JOIN shopping_cart ON shopping_cart_item.Cart_ID = shopping_cart.Cart_ID
WHERE Cus_ID = $cus_id";

$cart_result = mysqli_query($con, $cart_query);

//Book Quantity
$book_quantity_sql = "SELECT Cart_ID, count(Book_ID) AS Total_unique_ordered 
FROM shopping_cart_item WHERE Cart_ID = $cus_id";

$book_quantity_result = mysqli_query($con, $book_quantity_sql);
$book_quantity_row = mysqli_fetch_array($book_quantity_result);


if(isset($_POST['checkout'])){

    //Insert shopping cart items into order 
    $insert_order = "INSERT INTO `order` 
    (`Cus_ID`, `Total_Price`, `Payment_method`, `Delivery_type`) 
    VALUES  ('$cus_id','$total_price_shipping','Credit/Debit Card','$deliver_type')";
  
    if ($insert_order_result = mysqli_query($con, $insert_order)){
      echo '<script>
      alert("Your payment was successfully made!");
      </script>'; 
    }

    //latest order id of customer
    $order_id_sql = "SELECT Order_ID FROM `order` WHERE Cus_ID = $cus_id
    ORDER BY Order_ID DESC LIMIT 1";
    $order_id_result = mysqli_query($con, $order_id_sql);
    $order_id_row = mysqli_fetch_array($order_id_result);
    $order_id = $order_id_row['Order_ID'];
    
    //Shopping cart item into order details query
    $shopping_details_sql = "SELECT * FROM shopping_cart_item WHERE Cart_ID = $cus_id";
    $shopping_details_result = mysqli_query($con, $shopping_details_sql);
    while ($shopping_details_row = mysqli_fetch_array($shopping_details_result))
    {
      $book_id = $shopping_details_row['Book_ID'];
      $book_quantity = $shopping_details_row['Quantity'];
      $book_subtotal = $shopping_details_row['Subtotal'];

      //Insert shopping cart items into order details
      $insert_order_details = "INSERT INTO `order_details`
      (`Order_ID`, `Book_ID`, `Quantity`, `Subtotal`) 
      VALUES ('$order_id', '$book_id', '$book_quantity', '$book_subtotal')";
      $insert_order_details_result =  mysqli_query($con, $insert_order_details);

    }
  
  // Reset shopping cart price to 0 after checkout
  $reset_total_price = "UPDATE shopping_cart SET Total_Price = 0 WHERE Cus_ID = $cus_id";
  $reset_total_price_result = mysqli_query($con, $reset_total_price);

  //delete shopping cart item after checkout
  $delete  = "DELETE shopping_cart_item.* FROM shopping_cart INNER JOIN shopping_cart_item 
  ON shopping_cart.Cart_ID = shopping_cart_item.Cart_ID WHERE Cus_ID = $cus_id";

  $delete_result = mysqli_query($con, $delete);

  echo '<script> window.location.href = "MyPurchase.php"; </script>';
  
}
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Story Glory</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css"/>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;600;700&display=swap" rel="stylesheet">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  </head>

  <body>
    <!--------------------------------Mini Header-------------------------------->
    <section class="mini-header">

      <nav>
        <a href="home.php"><img src="images/logo.png"></a>
        <div class="search_logo">
          <a href="category.php?page=1&sort=&genre=&valueToSearch="><i class="fas fa-search"> Search for a book!</i></a>
        </div>
        <ul>
          <input id="adminvalue" type="hidden" value="<?php echo $checkAdmin; ?>">
          <li id="adminbutton"><a href="admin.php"><i class="fas fa-user-cog"></i> Admin</a></li>
          <li><a href="home.php"><i class="fas fa-igloo"></i> Home</a></li>
          <li><a href="category.php?page=1&sort=&genre=&valueToSearch="><i class="fas fa-layer-group"></i> Category</a></li>
          <li><a href="wishlist.php"><i class="fab fa-gratipay"></i> My Wishlist</a></li>
          <li><a href="Shopping_Cart.php"><i class="fas fa-shopping-cart"></i> Shopping Cart</a></li>
          <li><a href="MyPurchase.php"><i class="fas fa-shopping-bag"></i> My Purchase</a></li>
          <li><a href="account.php"><i class="fas fa-user-ninja"></i> My profile</a></li>
          <li class="logout" id="logout_btn"><a href="logout.php">Log Out</a></li>
        </ul>
      </nav>

        <h1>Payment &nbsp; Method</h1>

    </section>

        <!--------------------------------Shopping Header-------------------------------->

        <div class="shopping-row">
          <div id="progress3"></div>
              <div class="step-col"><small>1. Shopping Cart</small></div>
              <div class="step-col"><small>2. Shipping Details</small></div>
              <div class="step-col"><small>3. Payment Method</small></div>
        </div>
      
    <!--------------------------------Payment Method -------------------------------->
    <div class="payment-row">
      <div class="payment-left">
          <div class="payment-container">
              <form method="POST">
                  <div class="payment-row">
                      <div class="payment-info">
                          <h3>Billing Address</h3>

                          <?php

                          include("conn.php");

                          if(isset($cus_id))
                          {
                            $sql = "SELECT * 
                            FROM `customer`
                            WHERE Cus_ID = '$cus_id'";

                            $result = mysqli_query($con, $sql);

                            while($row = mysqli_fetch_array($result))
                            {
                          ?>

                          <input name="deliver_type" type="hidden" value=" <?php echo $deliver_type; ?>">
                          <label for="fname"><i class="fa fa-user"></i> Full Name</label>
                          <input type="text" id="fname" name="fullname" placeholder="Full Name" value="<?php echo $row['Name']; ?>"required>  
                          <label for="email"><i class="fa fa-envelope"></i> Email</label>
                          <input type="text" id="email" name="email" placeholder="Email" value="<?php echo $row['Email']; ?>"required>
                          <label for="adr"><i class="fa fa-address-card-o"></i> Address</label>
                          <input type="text" id="adr" name="address" placeholder="Address" value="<?php echo  $row['Shipping_Address']; ?>"required>
                          <label for="city"><i class="fa fa-institution"></i> City</label>
                          <input type="text" id="city" name="city" placeholder="Kuala Lumpur" required>

                          <?php
                            }
                          }
                          ?>

                          <div class="payment-row">
                              <div class="payment-info">
                                  <label for="state">State</label>
                                  <input type="text" id="state" name="state" placeholder="Selangor"required>
                              </div>
                              <div class="payment-info">
                                  <label for="zip">Zip</label>
                                  <input type="text" id="zip" name="zip" placeholder="47000"required>
                              </div>
                          </div>
                      </div>
  
                      <div class="payment-info">
                          <h3>Payment</h3>
                          <label for="fname">Accepted Cards</label>
                          <div class="payment-icon">
                              <i class="fab fa-cc-visa" style="color: navy;"></i>
                              <i class="fab fa-cc-mastercard" style="color:red;"></i>
                              <i class="fab fa-cc-amex" style="color:blue;"></i>
                          </div>
  
                          <label for="cname">Name on Card</label>
                          <input type="text" id="cname" name="cardname" placeholder="Card Name"required>
                          <label for="ccnum">Credit card number</label>
                          <input type="text" id="ccnum" name="cardnumber" placeholder="1111-2222-3333-4444"required>
                          <label for="expmonth">Exp Month</label>
                          <input type="text" id="expmonth" name="expmonth" placeholder="September"required>
                          <div class="payment-row">
                              <div class="payment-info">
                                  <label for="expyear">Exp Year</label>
                                  <input type="text" id="expyear" name="expyear" placeholder="2021"required>
                              </div>
                              <div class="payment-info">
                                  <label for="cvv">CVV</label>
                                  <input type="text" id="cvv" name="cvv" placeholder="352"required>
                              </div>
                          </div>
                      </div>
                  </div>
                  <label>
                  <input type="checkbox" checked="checked" name="checkbox"> Shipping address same as billing
                  </label>
                  <input name="checkout" type="submit" value="Continue to checkout" class="payment-btn">
          </div>
      </div>

      <div class="payment-cart">
          <div class="payment-container">
              <h4>Cart <span class="payment" style="color:black"><i class="fa fa-shopping-cart"></i> <b><?php echo $book_quantity_row['Total_unique_ordered']; ?></b></span></h4>
              <?php 
              while ($row = mysqli_fetch_array($cart_result))
              {
              ?>
              <br>
              <p class="title"><span ><?php echo $row['Title']; ?></span></p><span class="payment"><?php echo $row['Subtotal']; ?></span>
              <br>
              <?php
              }
              ?>
              <hr>
              <input name="total_price_hidden" type="hidden" value="<?php echo $total_price_shipping; ?>">
              <p>Total <span class="payment" style="color:black"><b><?php echo $total_price_shipping; ?></b></span></p>
          </div>
      </div>
  </div>
  </form>


    <!--------------------------------Footer-------------------------------->
    <section class="footer">

      <div class="footer-title">
        <h1>About us</h1>
        <p>This is what we are</p>
      </div>

      <div class="row">
          <div class="footer-col">
            <i class="fas fa-book-reader"></i>
            <h3>Value</h3>
            <p>This online bookstore is mainly about providing the best experience to customers when they visit our website as if they were in the physical bookstore, but online!<br>It provides convenience to people who still need physical books during the lockdown of the country.</p>
          </div>
          <div class="footer-col">
            <i class="fas fa-box-open"></i>
            <h3>Product</h3>
            <p>There are plenty of user-friendly features such as a handy navigation bar, shopping cart as well as help and support section.<br>Everyone is allowed to visit our website to find books they are interested in, but in order to buy them, they would have to register.<br>There will also be special discounts and promotions exclusive to members which customers could register to become one.</p>
          </div>
          <div class="footer-col">
            <i class="fas fa-truck"></i>
            <h3>Service</h3>
            <p>All purchased books will be delivered to the customers' location on time with our professional and trusted delivery service.<br>We also include 24/7 customer support to help customers with their issues!</p>
          </div>
      </div>

      <div class="footer-icon">
        <a href="https://www.facebook.com/profile.php?id=100060182020609" target="blank"><i class="fab fa-facebook-square"></i></a>
        <a href="https://www.instagram.com/storyglory_my/" target="blank"><i class="fab fa-instagram"></i></a>
        <p>Kindly contact us if you require any assistance.</p>
      </div>
      
    </section>
  </body>
  <script type="text/javascript" src="script.js"></script>

</html>