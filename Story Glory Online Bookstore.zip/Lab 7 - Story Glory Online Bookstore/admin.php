<?php
include("session.php");
  if(isset($_POST['update-delivery-status']))
  {
    include("conn.php");
    $del_status = $_POST['Delivery_status'];
    $order_id = $_POST['order_id'];
    $sql=" UPDATE `order` SET
    `Delivery_status` = '$del_status'
    WHERE `Order_ID` = '$order_id'";

    if(mysqli_query($con, $sql)) {
      mysqli_close($con);
      echo '<script>
      alert("Delivery Status Successfully Updated!");
      </script>';
    }
  }else
  if(isset($_POST['new-book']))
  {
    include("session.php");
    include("conn.php");
    $ISBN = $_POST['isbn'];
    $Price = $_POST['price'];
    $Pages = $_POST['pages'];
    $Title = $_POST['title'];
    $Format = $_POST['format'];
    $Author = $_POST['author'];
    $Publication_date = $_POST['date'];
    $Language = $_POST['language'];
    $Quantity = $_POST['qty'];
    $Summary = $_POST['summary'];
    $Cover = $_POST['cover'];
    $Genre = $_POST['genre'];

    $sql="INSERT INTO `book` (
    `ISBN`, `Price`, `Title`, `Author`, `Language`, `Summary`, `Genre`, `Pages`, `Format`, `Publication_Date`, `Quantity_Available`, `Cover`)
    VALUES
    ('$ISBN', '$Price', '$Title', '$Author', '$Language', '$Summary', '$Genre', '$Pages', '$Format', '$Publication_date', '$Quantity', '$Cover')";

    if(mysqli_query($con, $sql)) {
      mysqli_close($con);
      echo '<script>
      alert("Book Successfully Added!");
      </script>';
    }
  }else
  if(isset($_POST['set-admin']))
  {
    include("conn.php");
    $customer = $_POST['Cust_ID'];
    $sql=" UPDATE `customer` SET
    `Admin` = '1'
    WHERE `Cus_ID` = '$customer'";

    if(mysqli_query($con, $sql)) {
      mysqli_close($con);
      echo '<script>
      alert("Admin Account Successfully Updated!");
      </script>';
    }
  }
  
?>


<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Admin Dashboard - Story Glory</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css"/>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;600;700&display=swap" rel="stylesheet">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  </head>

  <body>
    <!--------------------------------Header-------------------------------->
    <section class="mini-header">

      <nav>
        <a href="home.php"><img src="images/logo.png"></a>
        <div class="search_logo">
          <a href="category.php?page=1&sort=&genre=&valueToSearch="><i class="fas fa-search"> Search for a book!</i></a>
        </div>
        <ul>
          <input id="adminvalue" type="hidden" value="<?php echo $checkAdmin; ?>">
          <li id="adminbutton"><a href="admin.php"><i class="fas fa-user-cog"></i> Admin</a></li>
          <li><a href="home.php"><i class="fas fa-igloo"></i> Home</a></li>
          <li><a href="category.php?page=1&sort=&genre=&valueToSearch="><i class="fas fa-layer-group"></i> Category</a></li>
          <li><a href="wishlist.php"><i class="fab fa-gratipay"></i> My Wishlist</a></li>
          <li><a href="Shopping_Cart.php"><i class="fas fa-shopping-cart"></i> Shopping Cart</a></li>
          <li><a href="MyPurchase.php"><i class="fas fa-shopping-bag"></i> My Purchase</a></li>
          <li><a href="account.php"><i class="fas fa-user-ninja"></i> My profile</a></li>
          <li class="logout" id="logout_btn"><a href="logout.php">Log Out</a></li>
        </ul>
      </nav>

      <h1>Admin Dashboard</h1>

    </section>

    <!--------------------------------Admin-------------------------------->

    <section class="admin">

      <div class="admin-acc">
        <h1>Admin</h1>
        <i class="fas fa-user-circle"></i>
      </div>

      <div class="admin-report">

        <div class="admin-report-col">
          <div class="report-title">
            <h2>Total Sales</h2>
            <i class="fas fa-chart-line"></i>
          </div>

          <?php


            include("conn.php");

            $query = "SELECT ROUND(SUM(Total_Price),2) AS 'Total Sales' FROM `order`";
            $result = mysqli_query($con, $query);
            $total_sales = mysqli_fetch_array($result);
            echo '<h6> RM '. $total_sales['Total Sales'] .'</h6>';

            mysqli_close($con);
            
          ?>

        </div>

        <div class="admin-report-col">
          <div class="report-title">
            <h2>Users Registered</h2>
            <i class="fas fa-search-dollar"></i>
          </div>

            <?php 

              include("conn.php");

              $query = "SELECT Cus_ID FROM customer";
              $result = mysqli_query($con, $query);

              $users_registered = mysqli_num_rows($result);
              echo '<h6>'. $users_registered .'</h6>';
              
              mysqli_close($con);

            ?>

        </div>

        <div class="admin-report-col">
          <div class="report-title">
            <h2>Order Received</h2>
            <i class="fas fa-dragon"></i>
          </div>

          <?php 

              include("conn.php");

              $query = "SELECT Order_ID FROM `order`";
              $result = mysqli_query($con, $query);

              $order_received = mysqli_num_rows($result);
              echo '<h6>'. $order_received .'</h6>';
              
              mysqli_close($con);

          ?>
      
        </div>

      </div><hr>    
    <!--------------------------------Book Editing-------------------------------->

      <div class="admin-book">
        <h1 class="admin-header">Books</h1>
        
        <form method="post" action="admin_search_book.php">
            <div class="admin-book-col">
              <div><i class="fas fa-search-dollar"></i>Search&nbsp;&nbsp;</div>
              <input type="text" name="search-name" placeholder="Search Book" required>
              <button type="submit" class="gold-btn" name="search-book">SEARCH</button>
              <button type="submit" class="gold-btn" name="search-book" formnovalidate>SHOW ALL</button>
              <button type="submit" class="gold-btn">UPDATE</button>
              <button type="submit" class="gold-btn" >DELETE</button>
          </div>
        </form>

        
        <div class="admin-book-col">
          <form method="post">
              <button type="submit" class="gold-btn" name="new-book"  onclick ="add_book()">NEW</button>
        </div>

        <!--------------------------------Javascript-------------------------------->

        <script>
            function add_book(){
                document.getElementById("new-book-form").style.display="block";
            }
        </script>

        <!--------------------------------New book-------------------------------->
        <table class="edit-book" id="new-book-form">

          <tr>
            <td>ISBN</td>
            <td>:</td>
            <td><input type="text" name="isbn" placeholder="ISBN" minlength="9" maxlength="9" required></td>

            <td>GENRE</td>
            <td>:</td>
            <td>
                <select name="genre" required>
                <option value="">Please select genre</option>
                <option value="Fantasy">Fantasy</option>
                <option value="Romance">Romance</option>
                <option value="Academic">Academic</option>
                <option value="Horror">Horror</option>
                <option value="Sci-Fi">Sci-Fi</option>
                <option value="Motivational">Motivational</option>
                <option value="Healthy">Healthy</option>
                <option value="History">History</option>
                <option value="Kids">Kids</option>
                </select>
            </td>
          </tr>

          <tr>
            <td>PRICE</td>
            <td>:</td>
            <td><input type="number" name="price" placeholder="Price" min="30" max="500" step="0.01" required></td>

            <td>PAGES</td>
            <td>:</td>
            <td><input type="number" name="pages" placeholder="Pages" min="30" max="500" required></td>
          </tr>

          <tr>
            <td>TITLE</td>
            <td>:</td>
            <td><input type="text" name="title" placeholder="Title" minlength="3" required></td>

            <td>FORMAT</td>
            <td>:</td>
            <td>
                <select name="format" required>
                <option value="">Please select format</option>
                <option value="Paper Bag">Paper Bag</option>
                <option value="Hardcover">Hardcover</option>
                </select>
            </td>
          </tr>

          <tr>
            <td>AUTHOR</td>
            <td>:</td>
            <td><input type="text" name="author" placeholder="Author"  minlength="3"  required></td>

            <td>PUBLICATION DATE</td>
            <td>:</td>
            <td><input type="date" name="date" placeholder="DD/MM/YYYY" required></td>
          </tr>

          <tr>
            <td>LANGUAGE</td>
            <td>:</td>
            <td>          
                <select name="language" required>
                <option value="">Please select language</option>
                <option value="English">English</option>
                <option value="Chinese">Chinese</option>
                <option value="Malay">Malay</option>
                <option value="Tamil">Tamil</option>
                </select>
            </td>

            <td>QUANTITY AVAILABLE</td>
            <td>:</td>
            <td><input type="number" name="qty" placeholder="Quantity" min="10" max="500" required></td>
          </tr>

          <tr>
            <td>BOOK SUMMARY</td>
            <td>:</td>
            <td><textarea name="summary" placeholder="Summary" minlength="10" required></textarea></td>

            <td>BOOK COVER</td>
            <td>:</td>
            <td><textarea name="cover" placeholder="url" minlength="5" required></textarea></td>
          </tr>

        </table>
        </form>
      </div>
      
      <hr>

    <!-- ------------------------- Recent Customers ------------------------------ -->
      <h1 class="admin-header">Delivery Status</h1>

      <div class="recent-customers">

        <form method="post">
          <div class="admin-book-col">
              <div><i class="fas fa-search-dollar"></i>Search&nbsp;&nbsp;</div>
              <input type="text" name="search-o" placeholder="Search Order Or Customer" required>
              <button type="submit" class="gold-btn" name="search-order">SEARCH</button>
              <button type="submit" class="gold-btn" name="search-order" formnovalidate>SHOW ALL</button>
          </div>
        </form>

        <?php
          include("conn.php");
          if(isset($_POST['search-order']))
          {
            $search_order = $_POST['search-o'];
  
            $query = "SELECT *
            FROM `customer`
            INNER JOIN `order` ON `customer`.Cus_ID = `order`.`Cus_ID`
            WHERE customer.`Name` LIKE '%$search_order%' OR
                  `order`.`Order_ID` LIKE '%$search_order%' OR
                  `order`.`Delivery_status` LIKE '%$search_order%' 
            ORDER BY `Order_ID` DESC";
          
            $result = mysqli_query($con, $query);
            
            // Return the number of rows in result set
            $rowcount=mysqli_num_rows($result);

            if ($rowcount == 0) {
              echo " <div class=\"no-books-found\"> No Orders Found </div>";
            }
  
            while($row = mysqli_fetch_array($result))
            {
        ?>
            <table class="recent-cus-col">
              <tr>
                <td id="rcc-order"><h3><?php echo $row['Order_ID'] ?></h3></td>
                <td><h3><?php echo $row['Name'] ?></h3></td>
                <td><h3><?php echo $row['Contact'] ?></h3></td>
                <td>
                  <form method="post">
                    <input type="hidden" name="order_id" value="<?php echo $row['Order_ID'] ?>">

                    <select name="Delivery_status" required>
                      <option value="">Please update delivery status</option>

                      <option value="Delivered"

                      <?php if($row['Delivery_status'] == "Delivered"){ ?> 
                        selected="selected"
                        <?php } ?> 

                      >Delivered</option>

                      <option value="Shipped"
                      
                      <?php if($row['Delivery_status'] == "Shipped"){ ?>
                        selected="selected"
                        <?php } ?> 

                      >Shipped</option>

                      <option value="Returned"
                      
                      <?php if($row['Delivery_status'] == "Returned"){ ?>
                        selected="selected"
                        <?php } ?> 
                      
                      >Returned</option>

                      <option value="Unsuccessful Delivery"
                      
                      <?php if($row['Delivery_status'] == "Unsuccessful Delivery"){ ?>
                        selected="selected"
                        <?php } ?> 
                      
                      >Unsuccessful Delivery</option>

                      <option value="Delay"
                      
                      <?php if($row['Delivery_status'] == "Delay"){ ?>
                        selected="selected"
                        <?php } ?> 

                      >Delay</option>

                    </select>
                    <button type="submit" class="gold-btn" name="update-delivery-status">UPDATE</button>

                  </form>
                </td>
              </tr>
            </table>
          <?php
            }
          }
          mysqli_close($con);
          ?>

      </div>
      <hr>

    <!-- ------------------------- Set Admin ------------------------------ -->
    <h1 class="admin-header">Set Admin</h1>

    <div class="recent-customers">

      <form method="post">
        <div class="admin-book-col">
            <div><i class="fas fa-search-dollar"></i>Search&nbsp;&nbsp;</div>
            <input type="text" name="search-username" placeholder="Search User" required>
            <button type="submit" class="gold-btn" name="search-user">SEARCH</button>
            <button type="submit" class="gold-btn" name="search-user" formnovalidate>SHOW ALL</button>
        </div>
      </form>


      <?php
        include("conn.php");
        if(isset($_POST['search-username']))
        {
          $search_username = $_POST['search-username'];

          $query = "SELECT *
          FROM `customer`
          WHERE `Name` LIKE '%$search_username%' 
          ORDER BY `Name` DESC";
        
          $result = mysqli_query($con, $query);

          // Return the number of rows in result set
          $rowcount=mysqli_num_rows($result);

          if ( $rowcount==0) {
            echo " <div class=\"no-books-found\"> No Users Found </div>";
          }

          while($row = mysqli_fetch_array($result))
          {
      ?>
        <table class="recent-cus-col">
          <form method="post">
            <tr>
              <input type="hidden" name="Cust_ID" value="<?php echo $row['Cus_ID']; ?>">
              <td id="rcc-order" ><h3> <?php echo $row['Cus_ID'] ?></h3></td>
              <td><h3><?php echo $row['Name'] ?></h3></td>

              <?php
                $user_type = intval($row['Admin']);

                if($user_type == 0){
                  $user_type = "Customer";
                } else 
                if($user_type == 1){
                  $user_type = "Admin";
                }
              ?>

              <td><h3><?php echo $user_type ?></h3></td>
              <td>
                  <button type="submit" class="gold-btn" id = "setAd" name="set-admin">Set Admin</button>
              </td>
            </tr>
          </form>
          </table>
        <?php
          }
        }
        mysqli_close($con);
        ?>

    </div>
    <hr>

    </section>



    <!--------------------------------Footer-------------------------------->
    <section class="footer">

      <div class="footer-title">
        <h1>About us</h1>
        <p>This is what we are</p>
      </div>

      <div class="row">
          <div class="footer-col">
            <i class="fas fa-book-reader"></i>
            <h3>Value</h3>
            <p>This online bookstore is mainly about providing the best experience to customers when they visit our website as if they were in the physical bookstore, but online!<br>It provides convenience to people who still need physical books during the lockdown of the country.</p>
          </div>
          <div class="footer-col">
            <i class="fas fa-box-open"></i>
            <h3>Product</h3>
            <p>There are plenty of user-friendly features such as a handy navigation bar, shopping cart as well as help and support section.<br>Everyone is allowed to visit our website to find books they are interested in, but in order to buy them, they would have to register.<br>There will also be special discounts and promotions exclusive to members which customers could register to become one.</p>
          </div>
          <div class="footer-col">
            <i class="fas fa-truck"></i>
            <h3>Service</h3>
            <p>All purchased books will be delivered to the customers' location on time with our professional and trusted delivery service.<br>We also include 24/7 customer support to help customers with their issues!</p>
          </div>
      </div>

      <div class="footer-icon">
        <a href="https://www.facebook.com/profile.php?id=100060182020609" target="_blank"><i class="fab fa-facebook-square"></i></a>
        <a href="https://www.instagram.com/storyglory_my/" target="blank"><i class="fab fa-instagram"></i></a>
        <p>Kindly contact us if you require any assistance.</p>
      </div>
      
    </section>
  </body>
  <script type="text/javascript" src="script.js"></script>

</html>