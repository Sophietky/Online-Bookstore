-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Nov 14, 2021 at 11:17 AM
-- Server version: 8.0.21
-- PHP Version: 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `story_glory`
--

-- --------------------------------------------------------

--
-- Table structure for table `book`
--

DROP TABLE IF EXISTS `book`;
CREATE TABLE IF NOT EXISTS `book` (
  `ISBN` int NOT NULL,
  `Price` float NOT NULL,
  `Title` varchar(110) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `Author` varchar(42) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `Language` varchar(8) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `Summary` varchar(1508) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `Genre` varchar(12) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `Pages` int NOT NULL,
  `Format` varchar(9) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `Publication_Date` date NOT NULL,
  `Quantity_Available` int NOT NULL,
  `Cover` varchar(88) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`ISBN`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `book`
--

INSERT INTO `book` (`ISBN`, `Price`, `Title`, `Author`, `Language`, `Summary`, `Genre`, `Pages`, `Format`, `Publication_Date`, `Quantity_Available`, `Cover`) VALUES
(13485867, 46, 'The Hating Game : TikTok made me buy it! The perfect enemies to lovers romcom', 'Sally Thorne', 'English', 'Not dislike. Not begrudgingly tolerate. HATE. Lucy can\'t understand Joshua\'s joyless, uptight approach to his job and refusal to smile. Joshua is clearly baffled by Lucy\'s overly bright clothes, quirkiness, and desire to be liked.', 'Romance', 91, 'Paper Bag', '2020-04-19', 53, 'https://d1w7fb2mkkr3kw.cloudfront.net/assets/images/book/lrg/9780/3494/9780349414263.jpg'),
(32091596, 362.13, 'Do Your Best Every Day to Do Your Best Every Day : Encouraging Words from John Cena', 'John Cena', 'English', 'New York Times bestselling authors Marc and Angel Chernoff deliver inspiring, actionable advice for keeping relationships strong--for couples, parents, friends, and more.', 'Motivational', 225, 'Paper Bag', '2013-07-17', 52, 'https://d1w7fb2mkkr3kw.cloudfront.net/assets/images/book/lrg/9780/5933/9780593377222.jpg'),
(32949039, 472, 'Guns, Germs and Steel : 20th Anniversary Edition', 'Jared Diamond', 'English', 'An ambitious synthesis of history, biology, ecology and linguistics, Guns, Germs and Steel is a ground-breaking and humane work of popular science that can provide expert insight into our modern world.', 'History', 97, 'Paper Bag', '2018-10-15', 47, 'https://d1w7fb2mkkr3kw.cloudfront.net/assets/images/book/lrg/9780/0993/9780099302780.jpg'),
(47792635, 431, 'The Love Hypothesis', 'Ali Hazelwood', 'English', 'When a fake relationship between scientists meets the irresistible force of attraction, it throws one woman\'s carefully calculated theories on love into chaos.', 'Romance', 153, 'Paper Bag', '2020-08-21', 84, 'https://d1w7fb2mkkr3kw.cloudfront.net/assets/images/book/lrg/9780/5933/9780593336823.jpg'),
(61817914, 260, 'The Scum Villain\'s Self-Saving System : Ren Zha Fanpai Zijiu Xitong: Vol 1', 'Mo Xiang Tong Xiu', 'English', 'Half-demon Luo Binghe rose from humble beginnings and a tortured past to become unrivaled in strength and beauty. With his harem of over three hundred wives, and dominion over both the human and demonic realms, he is truly the most powerful protagonist?in a trashy web novel series!', 'Fantasy', 97, 'Paper Bag', '2021-09-12', 19, 'https://d1w7fb2mkkr3kw.cloudfront.net/assets/images/book/lrg/9781/6482/9781648279218.jpg'),
(70414590, 467, 'Good Night Stories for Rebel Girls', 'Elena Favilli , By (author)  Francesca Cav', 'English', 'What if the princess didn\'t marry Prince Charming but instead went on to be an astronaut? What if the jealous step sisters were supportive and kind? And what if the queen was the one really in charge of the kingdom? Illustrated by sixty female artists from every corner of the globe, Good Night Stories for Rebel Girls introduces us to one hundred remarkable women and their extraordinary lives, from Ada Lovelace to Malala, Amelia Earhart to Michelle Obama. Empowering, moving and inspirational, these are true fairy tales for heroines who definitely don\'t need rescuing.', 'History', 126, 'Hardcover', '2017-09-07', 23, 'https://d1w7fb2mkkr3kw.cloudfront.net/assets/images/book/lrg/9780/1419/9780141986005.jpg'),
(97015936, 450, 'The Four Agreements : A Practical Guide to Personal Freedom (A Toltec Wisdom Book)', 'Don Miguel Ruiz', 'English', 'In The Four Agreements, bestselling author don Miguel Ruiz reveals the source of self-limiting beliefs that rob us of joy and create needless suffering. Based on ancient Toltec wisdom, The Four Agreements offer a powerful code of conduct that can rapidly transform our lives to a new experience of freedom, true happiness, and love.', 'Motivational', 144, 'Paper Bag', '2019-04-15', 91, 'https://d1w7fb2mkkr3kw.cloudfront.net/assets/images/book/lrg/9781/8784/9781878424310.jpg'),
(102828978, 459, 'House of Leaves : The Remastered Full-Color Edition', 'Mark Z. Danielewski', 'English', 'Years ago, when House of Leaves was first being passed around, it was nothing more than a badly bundled heap of paper, parts of which would occasionally surface on the Internet. No one could have anticipated the small but devoted following this terrifying story would soon command. Starting with an odd assortment of marginalized youth -- musicians, tattoo artists, programmers, strippers, environmentalists, and adrenaline junkies -- the book eventually made its way into the hands of older generations, who not only found themselves in those strangely arranged pages but also discovered a way back into the lives of their estranged children.', 'Horror', 79, 'Hardcover', '2019-08-11', 37, 'https://d1w7fb2mkkr3kw.cloudfront.net/assets/images/book/lrg/9780/3757/9780375703768.jpg'),
(133553279, 11, 'Roald Dahl\'s Marvellous Joke Book', 'Roald Dahl , Illustrated by  Quentin Blake', 'English', 'Laugh yourself silly with Roald Dahl\'s Marvellous Joke Book, filled with over 400 hilarious jokes, limericks and riddles, illustrated by Quentin Blake.\n\nBased on Roald Dahl\'s most famous characters you will be chortling away with Matilda, Charlie, George, The BFG, James and many more!', 'Kids', 66, 'Paper Bag', '2020-03-13', 54, 'https://d1w7fb2mkkr3kw.cloudfront.net/assets/images/book/lrg/9780/1413/9780141340555.jpg'),
(140213332, 86.63, 'Landslide : The Final Days of the Trump Presidency', 'Michael Wolff', 'English', 'Politics has given us some shocking and confounding moments but none have come close to the careening final days of Donald Trump\'s presidency: the surreal stage management of his re-election campaign, his audacious election challenge, the harrowing mayhem of the storming of the Capitol and the buffoonery of the second impeachment trial. But what was really going on in the inner sanctum of the White House during these calamitous events? What did the president and his dwindling cadre of loyalists actually believe? And what were they planning?', 'History', 357, 'Paper Bag', '2019-12-28', 68, 'https://d1w7fb2mkkr3kw.cloudfront.net/assets/images/book/lrg/9781/4087/9781408714652.jpg'),
(148149880, 264, 'Grandmaster of Demonic Cultivation : Mo Dao Zu Shi: Vol 1', 'Mo Xiang Tong Xiu', 'English', 'Wei Wuxian was once one of the most powerful men of his generation, a talented and clever young cultivator who harnessed martial arts and spirituality into powerful abilities. But when the horrors of war led him to seek more power through demonic cultivation, the world\'s respect for his abilities turned to fear, and his death was celebrated throughout the land.', 'Fantasy', 106, 'Hardcover', '2020-03-28', 39, 'https://d1w7fb2mkkr3kw.cloudfront.net/assets/images/book/lrg/9781/6482/9781648279195.jpg'),
(152273929, 256.61, 'Sapiens : A Brief History of Humankind', 'Yuval Noah Harari', 'English', 'What makes us brilliant? What makes us deadly? What makes us Sapiens? Yuval Noah Harari challenges everything we know about being human in the perfect read for these unprecedented times.', 'History', 465, 'Paper Bag', '2019-09-02', 24, 'https://d1w7fb2mkkr3kw.cloudfront.net/assets/images/book/lrg/9780/0995/9780099590088.jpg'),
(168713693, 313, 'Hollow City : The Second Novel of Miss Peregrine\'s Peculiar Children', 'Ransom Riggs', 'English', 'This second novel begins in 1940, immediately after the first book ended. Having escaped Miss Peregrine\'s island by the skin of their teeth, Jacob and his new friends must journey to London, the peculiar capital of the world. Along the way, they encounter new allies, a menagerie of peculiar animals, and other unexpected surprises. Complete with dozens of newly discovered (and thoroughly mesmerizing) vintage photographs, this new adventure will delight readers of all ages.', 'Horror', 65, 'Paper Bag', '2017-07-02', 81, 'https://d1w7fb2mkkr3kw.cloudfront.net/assets/images/book/lrg/9781/5947/9781594747359.jpg'),
(169775219, 255, 'The Subtle Art of Not Giving a F*ck : A Counterintuitive Approach to Living a Good Life', 'Mark Manson', 'English', 'Manson advises us to get to know our limitations and accept them. Once we embrace our fears, faults, and uncertainties, once we stop running and avoiding and start confronting painful truths, we can begin to find the courage, perseverance, honesty, responsibility, curiosity, and forgiveness we seek. There are only so many things we can give a f**k about so we need to figure out which ones really matter, Manson makes clear. While money is nice, caring about what you do with your life is better, because true wealth is about experience. A much-needed grab-you-by-the-shoulders-and-look-you-in-the-eye moment of real-talk, filled with entertaining stories and profane, ruthless humor, The Subtle Art of Not Giving a F**k is a refreshing slap for a generation to help them lead contented, grounded lives.', 'Motivational', 32, 'Hardcover', '2019-03-08', 42, 'https://d1w7fb2mkkr3kw.cloudfront.net/assets/images/book/lrg/9780/0624/9780062457714.jpg'),
(261940110, 451, 'Ross & Wilson Anatomy and Physiology in Health and Illness', 'Anne Waugh', 'English', 'The new edition of the hugely successful Ross and Wilson Anatomy & Physiology in Health and Illness continues to bring its readers the core essentials of human biology presented in a clear and straightforward manner. Fully updated throughout, the book now comes with enhanced learning features including helpful revision questions and an all new art programme to further clarify the explanations given in the text. The 13th edition retains its popular website, which contains a wide range of \'critical thinking\' exercises as well as new animations, an audio-glossary, the unique Body Spectrum (c) online colouring and self-test program, and helpful weblinks.', 'Healthy', 68, 'Paper Bag', '2019-11-02', 87, 'https://d1w7fb2mkkr3kw.cloudfront.net/assets/images/book/lrg/9780/7020/9780702072765.jpg'),
(276232485, 28, 'Sapiens : A Brief History of Humankind', 'Yuval Noah Harari', 'English', 'Interesting and provocative... It gives you a sense of how briefly we\'ve been on this Earth\' Barack Obama', 'History', 43, 'Paper Bag', '2021-01-10', 92, 'https://d1w7fb2mkkr3kw.cloudfront.net/assets/images/book/lrg/9780/0995/9780099590088.jpg'),
(347963130, 363, 'What to Do When You Worry Too Much : A Kid\'s Guide to Overcoming Anxiety', 'Dawn Huebner', 'English', 'What to Do When You Worry Too Much is an interactive self-help book designed to guide 6-12 year olds and their parents through the cognitive-behavioral techniques most often used in the treatment of generalised anxiety. Engaging, encouraging, and easy to follow, this book educates, motivates, and empowers children to work towards change.', 'Kids', 100, 'Hardcover', '2016-09-13', 45, 'https://d1w7fb2mkkr3kw.cloudfront.net/assets/images/book/lrg/9781/5914/9781591473145.jpg'),
(415293789, 449, 'The Seven Husbands of Evelyn Hugo : Tiktok made me buy it!', 'Taylor Jenkins Reid', 'English', '\"The epic adventures Evelyn creates over the course of a lifetime will leave every reader mesmerized. This wildly addictive journey of a reclusive Hollywood starlet and her tumultuous Tinseltown journey comes with unexpected twists and the most satisfying of drama.\" PopSugar', 'Romance', 42, 'Hardcover', '2018-01-29', 64, 'https://d1w7fb2mkkr3kw.cloudfront.net/assets/images/book/lrg/9781/9821/9781982147662.jpg'),
(416406088, 38.75, 'Fragments of Horror', 'Junji Ito', 'English', 'An old wooden mansion that turns on its inhabitants. A dissection class with a most unusual subject. A funeral where the dead are definitely not laid to rest. Ranging from the terrifying to the comedic, from the erotic to the loathsome, these stories showcase Junji Ito\'s long-awaited return to the world of horror.', 'Horror', 101, 'Paper Bag', '2018-08-25', 99, 'https://d1w7fb2mkkr3kw.cloudfront.net/assets/images/book/lrg/9781/4215/9781421580791.jpg'),
(446902724, 94.15, 'Death to Jar Sauce : Rad Recipes for Champions', ' Nat\'s What', 'English', 'The world’s a confusing and chaotic place. We thought lockdown was over . . . it wasn’t. We hoped life would go back to normal . . . it hasn’t.', 'Academic', 112, 'Paper Bag', '2015-10-15', 56, 'https://d1w7fb2mkkr3kw.cloudfront.net/assets/images/book/lrg/9781/7610/9781761045820.jpg'),
(455431961, 98.79, 'MEGAMONSTER', ' David Walliams ', 'English', 'On a volcanic island, in the middle of shark-infested waters, stands The Cruel School. The lessons are appalling, the school dinners are revolting and the teachers are terrifying - especially the mysterious Science teacher Doctor Doktur.', 'Kids', 212, 'Hardcover', '2017-02-27', 67, 'https://d1w7fb2mkkr3kw.cloudfront.net/assets/images/book/lrg/9780/0084/9780008487591.jpg'),
(459514857, 259, 'Health At Every Size : The Surprising Truth About Your Weight', 'Linda Bacon', 'English', 'Fat isn\'t the problem. Dieting is the problem. A society that rejects anyone whose body shape or size doesn\'t match an impossible ideal is the problem. A medical establishment that equates \"thin\" with \"healthy\" is the problem. The solution? Health at Every Size. Tune in to your body\'s expert guidance. Find the joy in movement. Eat what you want, when you want, choosing pleasurable foods that help you to feel good. You too can feel great in your body right now--and Health at Every Size will show you how. Health at Every Size has been scientifically proven to boost health and self-esteem. The program was evaluated in a government-funded academic study, its data published in well-respected scientific journals. Updated with the latest scientific research and even more powerful messages, Health at Every Size is not a diet book, and after reading it, you will be convinced the best way to win the war against fat is to give up the fight.', 'Healthy', 180, 'Paper Bag', '2017-10-24', 43, 'https://d1w7fb2mkkr3kw.cloudfront.net/assets/images/book/lrg/9781/9356/9781935618256.jpg'),
(461909842, 20.19, 'Brain Games For Clever Kids ®', ' Gareth Moore', 'English', 'Brain Games for Clever Kids (R) is a fantastic bestselling puzzle book, brimming with memory, word and number workouts for the cleverest of kids!', 'Kids', 45, 'Hardcover', '2020-06-16', 76, 'https://d1w7fb2mkkr3kw.cloudfront.net/assets/images/book/lrg/9781/7805/9781780552491.jpg'),
(478051377, 20.19, 'The Scout Mindset : Why Some People See Things Clearly and Others Don\'t', 'Julia Galef', 'English', 'A better way to combat knee-jerk biases and make smarter decisions, from Julia Galef, the acclaimed expert on rational decision-making.', 'Academic', 196, 'Hardcover', '2011-07-13', 90, 'https://d1w7fb2mkkr3kw.cloudfront.net/assets/images/book/mid/9780/5931/9780593189269.jpg'),
(492351810, 486, 'The Song of Achilles', 'Madeline Miller', 'English', 'Greece in the age of heroes. Patroclus, an awkward young prince, has been exiled to the court of King Peleus and his perfect son Achilles. Despite their differences, Achilles befriends the shamed prince, and as they grow into young men skilled in the arts of war and medicine, their bond blossoms into something deeper - despite the displeasure of Achilles\'s mother Thetis, a cruel sea goddess. But when word comes that Helen of Sparta has been kidnapped, Achilles must go to war in distant Troy and fulfill his destiny. Torn between love and fear for his friend, Patroclus goes with him, little knowing that the years that follow will test everything they hold dear.', 'Fantasy', 54, 'Paper Bag', '2017-07-16', 24, 'https://d1w7fb2mkkr3kw.cloudfront.net/assets/images/book/lrg/9781/4088/9781408891384.jpg'),
(502592261, 304, 'Wonder', 'R. J. Palacio', 'English', 'My name is August. I won\'t describe what I look like. Whatever you\'re thinking, it\'s probably worse.\' Auggie wants to be an ordinary ten-year-old. He does ordinary things - eating ice cream, playing on his Xbox. He feels ordinary - inside. But ordinary kids don\'t make other ordinary kids run away screaming in playgrounds. Ordinary kids aren\'t stared at wherever they go. Born with a terrible facial abnormality, Auggie has been home-schooled by his parents his whole life. Now, for the first time, he\'s being sent to a real school - and he\'s dreading it. All he wants is to be accepted - but can he convince his new classmates that he\'s just like them, underneath it all? Wonder is a funny, frank, astonishingly moving debut to read in one sitting, pass on to others, and remember long after the final page.', 'Kids', 83, 'Paper Bag', '2019-06-02', 2, 'https://d1w7fb2mkkr3kw.cloudfront.net/assets/images/book/lrg/9780/5525/9780552565974.jpg'),
(507716398, 281, 'Surrounded by Bad Bosses and Lazy Employees : or, How to Deal with Idiots at Work', 'Thomas Erikson', 'English', 'Surrounded by idiots at work? Fed up with a bad boss or lazy colleagues? Thomas Erikson, author of the runaway international bestseller Surrounded by Idiots, will help you handle them and get things done, the right way', 'Academic', 118, 'Hardcover', '2021-01-07', 23, 'https://d1w7fb2mkkr3kw.cloudfront.net/assets/images/book/lrg/9781/7850/9781785043406.jpg'),
(528118185, 365.38, 'The Witches\' Almanac: The Moon ― Transforming the Inner Spirit', 'Andrew Theitic ', 'English', 'Founded in 1971 by Elizabeth Pepper, the art director of Gourmet magazine for many years, The Witches’ Almanac is a witty, literate, and sophisticated publication that appeals to all those devoted to the Craft. At one level, it is a pop reference that will fascinate anyone interested in folklore, mythology, and culture; but at another, it is the most sophisticated and wide-ranging annual guide available today for the mystic enthusiast.', 'Fantasy', 204, 'Hardcover', '2020-02-01', 41, 'https://d1w7fb2mkkr3kw.cloudfront.net/assets/images/book/lrg/9780/5933/9780593327739.jpg'),
(533673558, 54.79, 'Any Way the Wind Blows', 'Rainbow Rowell', 'English', 'In Carry On, Simon Snow and his friends realized that everything they thought they understood about the world might be wrong. And in Wayward Son, they wondered whether everything they understood about themselves might be wrong.', 'Fantasy', 53, 'Hardcover', '2014-12-22', 25, 'https://d1w7fb2mkkr3kw.cloudfront.net/assets/images/book/lrg/9781/5290/9781529039924.jpg'),
(544145715, 420, 'Astrophysics for People in a Hurry', 'Neil deGrasse Tyson', 'English', 'There\'s no better guide through mind-expanding questions such as what the nature of space and time is, how we fit within the universe, and how the universe fits within us than Neil deGrasse Tyson.', 'Sci-Fi', 149, 'Paper Bag', '2016-06-05', 26, 'https://d1w7fb2mkkr3kw.cloudfront.net/assets/images/book/lrg/9780/3936/9780393609394.jpg'),
(636441413, 276.43, 'Artemis : A gripping sci-fi thriller from the author of The Martian', 'Andy Weir', 'English', 'Jazz Bashara is one of the criminals. She lives in a poor area of Artemis and subsidises her work as a porter with smuggling contraband onto the moon. But it\'s not enough.\n\nSo when she\'s offered the chance to make a lot of money she jumps at it. But though planning a crime in 1/6th gravity may be more fun, it\'s also a lot more dangerous.', 'Sci-Fi', 106, 'Paper Bag', '2016-08-18', 12, 'https://d1w7fb2mkkr3kw.cloudfront.net/assets/images/book/lrg/9781/7850/9781785030253.jpg'),
(649217212, 467.64, 'Acting with Power : Why We Are More Powerful Than We Believe', 'Deborah Gruenfeld', 'English', '\"A refreshing and enlightening new perspective on what it means to be powerful.\"--Susan Cain, bestselling author of Quiet We all know what it looks like to use power badly. But how much do we really know about how to use power well?', 'Motivational', 110, 'Hardcover', '2018-04-08', 76, 'https://d1w7fb2mkkr3kw.cloudfront.net/assets/images/book/lrg/9781/1019/9781101903971.jpg'),
(672352817, 493.16, 'The Secret Language of Your Body : The Essential Guide to Health and Wellness', 'Inna Segal', 'English', 'The Secret Language of Your Bodyis a comprehensive guide to healing. In this in-depth and comprehensive book, Inna Segal unveils the secrets to understanding the messages of the body and reveals the underlying energetic causes of over 200 symptoms and medical conditions. This powerful handbook explores nearly every conceivable part of the human body, delving deeply into the possible reasons for problems in any given area of the body and offering a unique, step-by-step method to assist in returning the body to its natural state of health.', 'Healthy', 320, 'Paper Bag', '2019-08-29', 100, 'https://d1w7fb2mkkr3kw.cloudfront.net/assets/images/book/lrg/9781/5827/9781582702605.jpg'),
(708487453, 115, 'A Brief History Of Time : From Big Bang To Black Holes', 'Stephen Hawking', 'English', 'These are just some of the questions considered in the internationally acclaimed masterpiece by the world renowned physicist - generally considered to have been one of the world\'s greatest thinkers. It begins by reviewing the great theories of the cosmos from Newton to Einstein, before delving into the secrets which still lie at the heart of space and time, from the Big Bang to black holes, via spiral galaxies and strong theory. To this day A Brief History of Time remains a staple of the scientific canon, and its succinct and clear language continues to introduce millions to the universe and its wonders.', 'Sci-Fi', 99, 'Hardcover', '2020-09-07', 4, 'https://d1w7fb2mkkr3kw.cloudfront.net/assets/images/book/lrg/9780/8575/9780857501004.jpg'),
(727883576, 20.19, 'Piranesi : WINNER OF THE WOMEN\'S PRIZE 2021', ' Susanna Clarke', 'English', 'In his notebooks, day after day, he makes a clear and careful record of its wonders: the labyrinth of halls, the thousands upon thousands of statues, the tides that thunder up staircases, the clouds that move in slow procession through the upper halls. On Tuesdays and Fridays Piranesi sees his friend, the Other. At other times he brings tributes of food to the Dead. But mostly, he is alone.', 'History', 120, 'Paper Bag', '2016-03-12', 50, 'https://d1w7fb2mkkr3kw.cloudfront.net/assets/images/book/lrg/9781/5266/9781526622433.jpg'),
(746431505, 94.15, 'The End of Her : A Novel', 'Shari Lapena', 'English', 'Stephanie and Patrick are adjusting to life with their colicky twin girls. The babies are a handful, but even as Stephanie struggles with the disorientation of sleep deprivation, there\'s one thing she\'s sure of: she has all she ever wanted.', 'Fantasy', 323, 'Paper Bag', '2021-08-19', 98, 'https://d1w7fb2mkkr3kw.cloudfront.net/assets/images/book/lrg/9780/5255/9780525508410.jpg'),
(762310171, 241, 'Ugly Love', 'Colleen Hoover', 'English', 'When Tate Collins finds airline pilot Miles Archer passed out in front of her apartment door, it is definitely not love at first sight. They wouldn\'t even go so far as to consider themselves friends. But what they do have is an undeniable mutual attraction.', 'Romance', 72, 'Paper Bag', '2020-01-16', 14, 'https://d1w7fb2mkkr3kw.cloudfront.net/assets/images/book/lrg/9781/4711/9781471136726.jpg'),
(795572441, 472.91, 'It Ends With Us: The most heartbreaking novel you\'ll ever read : The most heartbreaking novel you\'ll ever read', 'Sallyann Burtonwood', 'English', 'A brave and heartbreaking novel that digs its claws into you and doesn\'t let go, long after you\'ve finished it\' Anna Todd, author of the After series \'A glorious and touching read, a forever keeper\' USA Today \'Will break your heart while filling you with hope\' Sarah Pekkanen, Perfect Neighbors SOMETIMES THE ONE WHO LOVES YOU IS THE ONE WHO HURTS YOU THE MOST. Lily hasn\'t always had it easy, but that\'s never stopped her from working hard for the life she wants. She\'s come a long way from the small town in Maine where she grew up - she graduated from college, moved to Boston, and started her own business. So when she feels a spark with a gorgeous neurosurgeon named Ryle Kincaid, everything in Lily\'s life suddenly seems almost too good to be true. Ryle is assertive, stubborn, maybe even a little arrogant. He\'s also sensitive, brilliant, and has a total soft spot for Lily, but Ryle\'s complete aversion to relationships is disturbing. Even as Lily finds herself becoming the exception to his \'no dating\' rule, she can\'t help but wonder what made him that way in the first place. As questions about her new relationship overwhelm her, so do thoughts of Atlas Corrigan - her first love and a link to the past she left behind. He was her kindred spirit, her protector. When Atlas suddenly reappears, everything Lily has built with Ryle is threatened. With this bold and deeply personal novel, It Ends With Us is a heart-wrenching story and an unforgettable tale of love that comes at the ultimate price.', 'Romance', 238, 'Paper Bag', '2021-10-27', 34, 'https://d1w7fb2mkkr3kw.cloudfront.net/assets/images/book/lrg/9781/4711/9781471156267.jpg'),
(797288808, 94.15, 'Nine Perfect Strangers : The No 1 bestseller now a major Amazon Prime series', ' Liane Moriarty', 'English', 'Perfect lives or perfect lies? The unputdownable sunday times no. 1 bestseller and richard & judy book club pick, from the author of HBO\'s award winning big little lies', 'Academic', 449, 'Hardcover', '2015-09-28', 46, 'https://d1w7fb2mkkr3kw.cloudfront.net/assets/images/book/lrg/9781/4059/9781405919463.jpg'),
(813002399, 437, 'Ready for Anything : How to Build Resilience and Cope with Daily Stress', 'Dr Samantha Boardman', 'English', 'If you\'re depressed, burned out, or languishing, this book is brimming with practical ideas [...] for sustaining energy and well-being\' Adam Grant, #1 New York Times bestselling author of THINK AGAIN', 'Academic', 64, 'Hardcover', '2016-05-22', 39, 'https://d1w7fb2mkkr3kw.cloudfront.net/assets/images/book/lrg/9780/2412/9780241292211.jpg'),
(829906934, 85.56, 'An Ugly Truth : Inside Facebook\'s Battle for Domination', 'Sheera Frenkel , By (author)  Cecilia Kang', 'English', 'What marks this book out is how it gets under the corporate bonnet . . . to build a picture of astounding corporate arrogance and irresponsibility\' Sunday Times', 'Academic', 125, 'Hardcover', '2018-03-13', 80, 'https://d1w7fb2mkkr3kw.cloudfront.net/assets/images/book/lrg/9781/4087/9781408712719.jpg'),
(838996845, 441, 'Miss Peregrine\'s Home for Peculiar Children', 'Ransom Riggs', 'English', 'A mysterious island. An abandoned orphanage. And a strange collection of very curious photographs. It all waits to be discovered in Miss Peregrine\'s Home for Peculiar Children, an unforgettable novel that mixes fiction and photography in a thrilling reading experience. As our story opens, a horrific family tragedy sets sixteen-year-old Jacob journeying to a remote island off the coast of Wales, where he discovers the crumbling ruins of Miss Peregrine\'s Home for Peculiar Children. As Jacob explores its abandoned bedrooms and hallways, it becomes clear that the children who once lived here - one of whom was his own grandfather - were more than just peculiar. They may have been dangerous. They may have been quarantined on a desolate island for good reason. And somehow - impossible though it seems - they may still be alive. A spine-tingling fantasy illustrated with haunting vintage photography, Miss Peregrine\'s Home for Peculiar Children will delight adults, teens, and anyone who relishes an adventure in the shadows.', 'Horror', 67, 'Hardcover', '2018-07-27', 28, 'https://d1w7fb2mkkr3kw.cloudfront.net/assets/images/book/lrg/9781/5947/9781594746031.jpg'),
(859123474, 154, 'Start With Why : How Great Leaders Inspire Everyone To Take Action', 'Simon Sinek', 'English', 'Why are some people and organizations more inventive, pioneering and successful than others? And why are they able to repeat their success again and again?', 'Motivational', 57, 'Paper Bag', '2018-01-07', 43, 'https://d1w7fb2mkkr3kw.cloudfront.net/assets/images/book/lrg/9780/2419/9780241958223.jpg'),
(883122400, 496, 'The Good Enough Parent: How to raise contented, interesting and resilient children', 'The School of Life', 'English', 'Raising a child to be an authentic and mentally robust adult is one of life\'s great challenges. It is also, fortunately, not a matter of luck. There are many things to understand about how children\'s minds operate and what they need from those who look after them so they can develop into the best version of themselves.', 'Academic', 89, 'Paper Bag', '2021-08-30', 87, 'https://d1w7fb2mkkr3kw.cloudfront.net/assets/images/book/lrg/9781/9128/9781912891542.jpg'),
(909069649, 61.73, 'Beautiful World, Where Are You : from the internationally bestselling author of Normal People', 'Sally Rooney', 'English', 'Alice, a novelist, meets Felix, who works in a warehouse, and asks him if he\'d like to travel to Rome with her. In Dublin, her best friend Eileen is getting over a break-up and slips back into flirting with Simon, a man she has known since childhood.', 'Romance', 416, 'Paper Bag', '2017-09-03', 52, 'https://d1w7fb2mkkr3kw.cloudfront.net/assets/images/book/lrg/9780/5713/9780571365425.jpg'),
(942841242, 87, '12 Rules for Life : An Antidote to Chaos', 'Jordan B. Peterson', 'English', 'The #1 Sunday Times bestseller from \'the most influential public intellectual in the Western world right now\' (New York Times) - now in paperback.\n\nHow should we live properly in a world of chaos and uncertainty?\n\nJordan Peterson has helped millions of people, young and old, men and women, aim at a life of responsibility and meaning. Now he can help you.', 'Motivational', 56, 'Paper Bag', '2018-09-04', 25, 'https://d1w7fb2mkkr3kw.cloudfront.net/assets/images/book/lrg/9780/1419/9780141988511.jpg'),
(953252633, 372, 'Dune', 'Frank Herbert', 'English', 'Set on the desert planet Arrakis, Dune is the story of the boy Paul Atreides, heir to a noble family tasked with ruling an inhospitable world where the only thing of value is the \"spice\" melange, a drug capable of extending life and enhancing consciousness. Coveted across the known universe, melange is a prize worth killing for....', 'Fantasy', 60, 'Paper Bag', '2015-11-02', 3, 'https://d1w7fb2mkkr3kw.cloudfront.net/assets/images/book/lrg/9780/4411/9780441172719.jpg'),
(953383237, 37, 'Piranesi : WINNER OF THE WOMEN\'S PRIZE 2021', 'Susanna Clarke', 'English', 'In his notebooks, day after day, he makes a clear and careful record of its wonders: the labyrinth of halls, the thousands upon thousands of statues, the tides that thunder up staircases, the clouds that move in slow procession through the upper halls. On Tuesdays and Fridays Piranesi sees his friend, the Other. At other times he brings tributes of food to the Dead. But mostly, he is alone.', 'Fantasy', 50, 'Hardcover', '2019-06-16', 26, 'https://d1w7fb2mkkr3kw.cloudfront.net/assets/images/book/lrg/9781/5266/9781526622433.jpg'),
(961506469, 18.26, 'The Ballad of Songbirds and Snakes (A Hunger Games Novel)', 'Suzanne Collins', 'English', 'It is the morning of the reaping that will kick off the tenth\nannual Hunger Games. In the Capitol, eighteen-year-old Coriolanus\nSnow is preparing for his one shot at glory as a mentor in the Games.\nThe once-mighty house of Snow has fallen on hard times, its\nfate hanging on the slender chance that Coriolanus will be able\nto outcharm, outwit, and outmaneuvre his fellow students to mentor\nthe winning tribute.', 'Fantasy', 225, 'Hardcover', '2017-05-24', 32, 'https://d1w7fb2mkkr3kw.cloudfront.net/assets/images/book/lrg/9780/7023/9780702309519.jpg'),
(966120947, 160, 'The Silk Roads : A New History of the World', 'Peter Frank', 'English', 'For centuries, fame and fortune was to be found in the west in the New World of the Americas. Today, it is the east which calls out to those in search of adventure and riches. The region stretching from eastern Europe and sweeping right across Central Asia deep into China and India, is taking centre stage in international politics, commerce and culture and is shaping the modern world.', 'History', 62, 'Hardcover', '2017-04-26', 15, 'https://d1w7fb2mkkr3kw.cloudfront.net/assets/images/book/lrg/9781/4088/9781408839997.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
CREATE TABLE IF NOT EXISTS `customer` (
  `Cus_ID` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(18) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `Password` varchar(12) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `Contact` varchar(12) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `Email` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `Subscription` tinyint(1) NOT NULL,
  `Shipping_Address` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `Admin` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`Cus_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`Cus_ID`, `Name`, `Password`, `Contact`, `Email`, `Subscription`, `Shipping_Address`, `Admin`) VALUES
(1, 'Tamarah Sparrowe', 'PKKYCzkxptDj', '724 282 4375', 'tsparrowe0@twitpic.com', 1, '6070 Corry Point', 0),
(2, 'Livia Lemanu', 'fSwKQB6ZrY', '859 900 0962', 'llemanu1@wired.com', 0, '2 Toban Trail', 0),
(3, 'Elihu Medway', '0RgXuVA', '654 616 5619', 'emedway2@google.fr', 1, '82 Namekagon Point', 0),
(4, 'Shell Meigh', 'QdCymK', '867 123 5721', 'smeigh3@state.tx.us', 1, '46285 Sloan Point', 0),
(5, 'Virginie Askwith', 'J9Neip', '277 685 5739', 'vaskwith4@unicef.org', 0, '29 Blue Bill Park Junction', 0),
(6, 'Nannie Askaw', 'L0FH13L', '508 247 7697', 'naskaw5@twitter.com', 1, '716 Prairie Rose Street', 0),
(7, 'Gilberta Cowton', '1prR2But1BHq', '583 967 5220', 'gcowton6@google.it', 0, '6 School Street', 0),
(8, 'Bailey Kassidy', 'TNYyNElvg', '970 206 1534', 'bkassidy7@mozilla.org', 1, '921 Michigan Point', 0),
(9, 'Perri Brake', 'uwzJY1Zc', '133 364 4661', 'pbrake8@fda.gov', 0, '952 Milwaukee Avenue', 0),
(10, 'Britney MacMorland', 'sptvhFGD', '944 430 0770', 'bmacmorland9@nsw.gov.au', 0, '5647 Derek Crossing', 0),
(11, 'Evan Fasse', 'HZAmbfN', '520 758 5892', 'efassea@ebay.co.uk', 1, '6 Schiller Point', 0),
(12, 'Carce Feather', 'gszEcXI5', '678 379 8434', 'cfeatherb@shareasale.com', 1, '38 Hintze Point', 0),
(13, 'Nat Leonard', 'JoKZt35', '197 784 9893', 'nleonardc@google.ru', 0, '6 Emmet Street', 0),
(14, 'Giselbert Carme', '2KA52hEmoW1', '317 126 6316', 'gcarmed@mtv.com', 0, '4 8th Point', 0),
(15, 'Dela Stadden', '33ESbx', '414 559 6501', 'dstaddene@furl.net', 1, '18358 Kingsford Hill', 0),
(16, 'Carny Deport', 'h4HTwoCLb', '969 577 7423', 'cdeportf@lulu.com', 0, '3295 Pepper Wood Alley', 0),
(17, 'Joly Trowell', 'hC0SDFh6', '512 606 8169', 'jtrowellg@irs.gov', 1, '249 Farwell Center', 0),
(18, 'Scottie Twohig', 'me0ihNuoPnEz', '938 520 7851', 'stwohigh@storify.com', 0, '187 Nelson Center', 0),
(19, 'Guenna Barwis', 'cItzla', '998 852 6017', 'gbarwisi@nyu.edu', 0, '050 Warbler Road', 0),
(20, 'Harris Brinkman', 'AWEkvD5YUiV', '582 290 9990', 'hbrinkmanj@nyu.edu', 1, '3668 South Point', 0),
(21, 'Admin', 'admin123', '601029384', 'sophie@gmail.com', 0, 'Jalan Anywhere', 1),
(22, 'test', 'pass', '0127383746', 'test@gmail.com', 0, 'Jalan Testing', 1);

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

DROP TABLE IF EXISTS `feedback`;
CREATE TABLE IF NOT EXISTS `feedback` (
  `FB_ID` int NOT NULL AUTO_INCREMENT,
  `Cus_ID` int NOT NULL,
  `Book_ID` int NOT NULL,
  `Date` date NOT NULL DEFAULT (cast(now() as date)),
  `Rating` int NOT NULL,
  `Feedback` varchar(217) NOT NULL,
  PRIMARY KEY (`FB_ID`),
  KEY `Cus_ID_F_FK` (`Cus_ID`),
  KEY `Book_ID_F_FK` (`Book_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`FB_ID`, `Cus_ID`, `Book_ID`, `Date`, `Rating`, `Feedback`) VALUES
(1, 1, 727883576, '2021-10-12', 3, 'Got it for an unbelievable price, and it came in pretty good condition except a tiny little wrinkle at the edge due to the tight plastic wrap. Very happy with the purchase overall.'),
(2, 2, 672352817, '2021-10-15', 5, 'It was a good read i must say. After the first crazy rich asian book, i just can help myself to buy this one. It was worthed. The delivery was fast enough for me.. i dont have to wait for a week to have it delivered. '),
(3, 3, 455431961, '2021-10-26', 4, 'There are so many characters in this book so you really have to keep up. The story began to build up towards the end. A fun read.'),
(4, 4, 32091596, '2021-10-27', 5, 'the book is in a good condition. cant wait to read'),
(5, 5, 727883576, '2021-10-28', 5, 'Amazing story, charachters and enjoyable?'),
(6, 6, 455431961, '2021-10-30', 4, 'My son really loved reading this book. He can\'t stop reading it.'),
(7, 7, 152273929, '2021-11-02', 3, 'The fore edge is very dirty!'),
(8, 8, 32091596, '2021-11-06', 3, 'Enjoying this book so far'),
(9, 9, 416406088, '2021-11-08', 1, 'item can in good condition and a really good price ??'),
(10, 10, 533673558, '2021-11-11', 2, 'Will buy again');

-- --------------------------------------------------------

--
-- Table structure for table `order`
--

DROP TABLE IF EXISTS `order`;
CREATE TABLE IF NOT EXISTS `order` (
  `Order_ID` int NOT NULL AUTO_INCREMENT,
  `Cus_ID` int NOT NULL,
  `Date` date NOT NULL DEFAULT (cast(now() as date)),
  `Total_Price` float NOT NULL,
  `Payment_method` varchar(25) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `Delivery_type` varchar(17) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `Delivery_status` varchar(22) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  PRIMARY KEY (`Order_ID`),
  KEY `Cus_ID` (`Cus_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `order`
--

INSERT INTO `order` (`Order_ID`, `Cus_ID`, `Date`, `Total_Price`, `Payment_method`, `Delivery_type`, `Delivery_status`) VALUES
(1, 1, '2021-09-04', 80.76, 'Credit/Debit Card', 'Next Day Delivery', 'Unsuccessful Delivery'),
(2, 2, '2021-09-05', 2465.8, 'Credit/Debit Card', 'Next Day Delivery', 'Delivered'),
(3, 3, '2021-09-06', 569.54, 'Credit/Debit Card', 'Standard Shipping', 'Returned'),
(4, 4, '2021-09-12', 1810.65, 'Credit/Debit Card', 'Next Day Delivery', 'Unsuccessful Delivery'),
(5, 5, '2021-09-19', 302.64, 'Credit/Debit Card', 'Standard Shipping', 'Delivered'),
(6, 6, '2021-10-03', 484.67, 'Credit/Debit Card', 'Standard Shipping', 'Shipped'),
(7, 7, '2021-10-04', 350.76, 'Credit/Debit Card', 'Standard Shipping', 'Returned'),
(8, 8, '2021-10-06', 2067.33, 'Credit/Debit Card', 'Standard Shipping', 'Delivered'),
(9, 9, '2021-10-09', 193.75, 'Credit/Debit Card', 'Standard Shipping', 'Shipped'),
(10, 10, '2021-10-09', 164.37, 'Credit/Debit Card', 'Next Day Delivery', 'Unsuccessful Delivery');

-- --------------------------------------------------------

--
-- Table structure for table `order_details`
--

DROP TABLE IF EXISTS `order_details`;
CREATE TABLE IF NOT EXISTS `order_details` (
  `Order_Item_ID` int NOT NULL AUTO_INCREMENT,
  `Order_ID` int NOT NULL,
  `Book_ID` int NOT NULL,
  `Quantity` int NOT NULL,
  `Subtotal` float NOT NULL,
  PRIMARY KEY (`Order_Item_ID`),
  KEY `Book_ID_OD_FK` (`Book_ID`),
  KEY `Order_ID_OD_FK` (`Order_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `order_details`
--

INSERT INTO `order_details` (`Order_Item_ID`, `Order_ID`, `Book_ID`, `Quantity`, `Subtotal`) VALUES
(1, 1, 727883576, 4, 80.76),
(2, 2, 672352817, 5, 2465.8),
(3, 3, 455431961, 1, 98.79),
(4, 3, 446902724, 5, 470.75),
(5, 4, 32091596, 5, 1810.65),
(6, 6, 455431961, 3, 296.37),
(7, 7, 797288808, 5, 94.15),
(8, 7, 152273929, 3, 256.61),
(9, 5, 727883576, 1, 20.19),
(10, 5, 797288808, 3, 282.45),
(11, 6, 746431505, 2, 188.3),
(12, 8, 32091596, 5, 1810.65),
(13, 8, 829906934, 3, 256.68),
(14, 9, 416406088, 5, 193.75),
(15, 10, 533673558, 3, 164.37);

-- --------------------------------------------------------

--
-- Table structure for table `shopping_cart`
--

DROP TABLE IF EXISTS `shopping_cart`;
CREATE TABLE IF NOT EXISTS `shopping_cart` (
  `Cart_ID` int NOT NULL AUTO_INCREMENT,
  `Cus_ID` int NOT NULL,
  `Total_Price` float NOT NULL,
  PRIMARY KEY (`Cart_ID`),
  KEY `Cus_ID_SC_FK` (`Cus_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `shopping_cart`
--

INSERT INTO `shopping_cart` (`Cart_ID`, `Cus_ID`, `Total_Price`) VALUES
(1, 1, 1810.65),
(2, 2, 5104.29),
(3, 3, 1826.9),
(4, 4, 383.53),
(5, 5, 783.76),
(6, 6, 6052.46),
(7, 7, 793.99),
(8, 8, 239.98),
(9, 9, 1218.71),
(10, 10, 956.76);

-- --------------------------------------------------------

--
-- Table structure for table `shopping_cart_item`
--

DROP TABLE IF EXISTS `shopping_cart_item`;
CREATE TABLE IF NOT EXISTS `shopping_cart_item` (
  `Cart_Item_ID` int NOT NULL AUTO_INCREMENT,
  `Cart_ID` int NOT NULL,
  `Book_ID` int NOT NULL,
  `Quantity` int NOT NULL,
  `Subtotal` float NOT NULL,
  PRIMARY KEY (`Cart_Item_ID`),
  KEY `Book_ID` (`Book_ID`),
  KEY `Cart_ID` (`Cart_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `shopping_cart_item`
--

INSERT INTO `shopping_cart_item` (`Cart_Item_ID`, `Cart_ID`, `Book_ID`, `Quantity`, `Subtotal`) VALUES
(1, 1, 32091596, 5, 1810.65),
(2, 2, 672352817, 9, 4438.44),
(3, 2, 727883576, 6, 121.14),
(4, 2, 746431505, 5, 100.95),
(5, 3, 528118185, 5, 1826.9),
(6, 4, 533673558, 7, 383.53),
(7, 5, 746431505, 2, 188.3),
(8, 5, 961506469, 7, 127.82),
(9, 5, 649217212, 1, 467.64),
(10, 6, 152273929, 7, 1796.27),
(11, 6, 795572441, 9, 4256.19),
(12, 7, 140213332, 8, 693.04),
(13, 7, 461909842, 5, 100.95),
(14, 8, 533673558, 1, 54.79),
(15, 8, 909069649, 3, 185.19),
(16, 9, 636441413, 2, 552.86),
(17, 9, 446902724, 6, 564.9),
(18, 9, 478051377, 5, 100.95),
(19, 10, 32091596, 2, 724.26),
(20, 10, 416406088, 6, 232.5);

-- --------------------------------------------------------

--
-- Table structure for table `wishlist`
--

DROP TABLE IF EXISTS `wishlist`;
CREATE TABLE IF NOT EXISTS `wishlist` (
  `Wish_ID` int NOT NULL AUTO_INCREMENT,
  `Cus_ID` int NOT NULL,
  `Book_ID` int NOT NULL,
  PRIMARY KEY (`Wish_ID`),
  KEY `Cus_ID_W_FK` (`Cus_ID`),
  KEY `Book_ID_W_FK` (`Book_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `wishlist`
--

INSERT INTO `wishlist` (`Wish_ID`, `Cus_ID`, `Book_ID`) VALUES
(1, 1, 961506469),
(2, 2, 446902724),
(3, 2, 533673558),
(4, 4, 649217212),
(5, 5, 446902724),
(6, 6, 909069649),
(8, 8, 478051377),
(9, 9, 152273929),
(10, 10, 533673558),
(11, 11, 455431961),
(12, 12, 795572441),
(13, 13, 528118185),
(14, 14, 746431505),
(15, 15, 533673558),
(16, 16, 797288808),
(17, 17, 649217212),
(18, 18, 746431505),
(19, 19, 32091596),
(20, 20, 746431505);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `feedback`
--
ALTER TABLE `feedback`
  ADD CONSTRAINT `Book_ID_F_FK` FOREIGN KEY (`Book_ID`) REFERENCES `book` (`ISBN`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `Cus_ID_F_FK` FOREIGN KEY (`Cus_ID`) REFERENCES `customer` (`Cus_ID`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Constraints for table `order`
--
ALTER TABLE `order`
  ADD CONSTRAINT `Cus_ID` FOREIGN KEY (`Cus_ID`) REFERENCES `customer` (`Cus_ID`);

--
-- Constraints for table `order_details`
--
ALTER TABLE `order_details`
  ADD CONSTRAINT `Book_ID_OD_FK` FOREIGN KEY (`Book_ID`) REFERENCES `book` (`ISBN`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `Order_ID_OD_FK` FOREIGN KEY (`Order_ID`) REFERENCES `order` (`Order_ID`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Constraints for table `shopping_cart`
--
ALTER TABLE `shopping_cart`
  ADD CONSTRAINT `Cus_ID_SC_FK` FOREIGN KEY (`Cus_ID`) REFERENCES `customer` (`Cus_ID`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Constraints for table `shopping_cart_item`
--
ALTER TABLE `shopping_cart_item`
  ADD CONSTRAINT `Book_ID_SCI_FK` FOREIGN KEY (`Book_ID`) REFERENCES `book` (`ISBN`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `Cart_ID_SCI_FK` FOREIGN KEY (`Cart_ID`) REFERENCES `shopping_cart` (`Cart_ID`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Constraints for table `wishlist`
--
ALTER TABLE `wishlist`
  ADD CONSTRAINT `Book_ID_W_FK` FOREIGN KEY (`Book_ID`) REFERENCES `book` (`ISBN`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `Cus_ID_W_FK` FOREIGN KEY (`Cus_ID`) REFERENCES `customer` (`Cus_ID`) ON DELETE RESTRICT ON UPDATE RESTRICT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
