// NAV BAR
// Admin button
var adminvalue = document.getElementById("adminvalue").value;

if (adminvalue == "1"){
    document.getElementById('adminbutton').style.display = "block";
}else{
    document.getElementById('adminbutton').style.display = "none";
};

// Login and Sign up button display
if (adminvalue == "0" || adminvalue == "1"){
    document.getElementById('login_button').style.display = "none";
    
}
// Logout button display
if (adminvalue == "") {
    document.getElementById('logout_btn').style.display = "none";
}else{
    document.getElementById('logout_btn').style.display = "block";
}

//account
function display_contact_edit(){
    document.getElementById("contact_edit_form").style.display = "block";
}
function display_email_edit(){
    document.getElementById("email_edit_form").style.display = "block";
}
function display_address_edit(){
    document.getElementById("address_edit_form").style.display = "block";
}
function display_username_edit(){
    document.getElementById("username_edit_form").style.display = "block";
}
function display_password_edit(){
    document.getElementById("password_edit_form").style.display = "block";
}
function cancelEdit_contact(){
    document.getElementById("contact_edit_form").style.display = "none";
}
function cancelEdit_email(){
    document.getElementById("email_edit_form").style.display = "none";
}
function cancelEdit_address(){
    document.getElementById("address_edit_form").style.display = "none";
}
function cancelEdit_username(){
    document.getElementById("username_edit_form").style.display = "none";
}
function cancelEdit_password(){
    document.getElementById("password_edit_form").style.display = "none";
}