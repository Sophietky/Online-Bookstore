<?php
include("session.php");
  if(isset($_POST['update-book']))
  {
    include("conn.php");
    $old_ISBN = $_POST['old_isbn'];
    $new_ISBN = $_POST['new_isbn'];
    $Price = $_POST['price'];
    $Pages = $_POST['pages'];
    $Title = $_POST['title'];
    $Format = $_POST['format'];
    $Author = $_POST['author'];
    $Publication_date = $_POST['date'];
    $Language = $_POST['language'];
    $Quantity = $_POST['qty'];
    $Summary = $_POST['summary'];
    $Cover = $_POST['cover'];
    $Genre = $_POST['genre'];

    $query=" UPDATE `book` SET
    `ISBN` = '$new_ISBN',
    `Price` = '$Price',  
    `Title` = '$Title',  
    `Author` = '$Author',  
    `Language` = '$Language', 
    `Summary` = '$Summary', 
    `Genre` = '$Genre', 
    `Pages` = '$Pages', 
    `Format` = '$Format', 
    `Publication_Date` = '$Publication_date', 
    `Quantity_Available` = '$Quantity', 
    `Cover` = '$Cover'
    WHERE `ISBN` = '$old_ISBN'";

    if(mysqli_query($con, $query)) {
      mysqli_close($con);
      echo '<script>
      alert("Book Information Successfully Updated!");
      </script>';
    }

  }else
  if(isset($_POST['delete-book']))
  {
    include("conn.php");
    $ISBN = $_POST['old_isbn'];
    $sql = "DELETE FROM `book` WHERE `ISBN` = '$ISBN'";

    if(mysqli_query($con, $sql)) {
      mysqli_close($con);
      echo '<script>
      alert("Book Successfully Removed!");
      </script>';
    }
  }
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Admin Dashboard - Story Glory</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css"/>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;600;700&display=swap" rel="stylesheet">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  </head>

  <body>
    <!--------------------------------Header-------------------------------->
    <section class="mini-header">

      <nav>
        <a href="home.php"><img src="images/logo.png"></a>
        <div class="search_logo">
          <a href="category.php?page=1&sort=&genre=&valueToSearch="><i class="fas fa-search"> Search for a book!</i></a>
        </div>
        <ul>
          <input id="adminvalue" type="hidden" value="<?php echo $checkAdmin; ?>">
          <li id="adminbutton"><a href="admin.php"><i class="fas fa-user-cog"></i> Admin</a></li>
          <li><a href="home.php"><i class="fas fa-igloo"></i> Home</a></li>
          <li><a href="category.php?page=1&sort=&genre=&valueToSearch="><i class="fas fa-layer-group"></i> Category</a></li>
          <li><a href="wishlist.php"><i class="fab fa-gratipay"></i> My Wishlist</a></li>
          <li><a href="Shopping_Cart.php"><i class="fas fa-shopping-cart"></i> Shopping Cart</a></li>
          <li><a href="MyPurchase.php"><i class="fas fa-shopping-bag"></i> My Purchase</a></li>
          <li><a href="account.php"><i class="fas fa-user-ninja"></i> My profile</a></li>
          <li class="logout" id="logout_btn"><a href="logout.php">Log Out</a></li>
        </ul>
      </nav>

      <h1>Admin Dashboard - Books Editing</h1>

    </section>
    <!--------------------------------Admin-------------------------------->

    <section class="admin">

      <div class="admin-acc">
        <h1>Admin</h1>
        <i class="fas fa-user-circle"></i>
      </div>

        <!-------------------------------- Search Bar-------------------------------->

            <form method="post" action="admin_search_book.php">
                <div class="admin-book-col">
                    <div><i class="fas fa-search-dollar"></i>Search&nbsp;&nbsp;</div>
                    <input type="text" name="search-name" placeholder="Search Book" required>
                    <button type="submit" class="gold-btn" name="search-book">SEARCH</button>
                    <button type="submit" class="gold-btn" name="search-book" formnovalidate>SHOW ALL</button>
                </div>
            </form>

        <!-------------------------------- Search Result-------------------------------->
        
          <?php
              include("conn.php");
              if(isset($_POST['search-name']))
              {
                $search_name = $_POST['search-name'];

                $query = "SELECT *
                FROM `book`
                WHERE `ISBN` LIKE '%$search_name%' OR 
                `Price` LIKE '%$search_name%' OR 
                `Title` LIKE '%$search_name%' OR 
                `Author` LIKE '%$search_name%' OR 
                `Language` LIKE '%$search_name%' OR 
                `Summary` LIKE '%$search_name%' OR 
                `Genre` LIKE '%$search_name%' OR 
                `Pages` LIKE '%$search_name%' OR 
                `Format` LIKE '%$search_name%' OR 
                `Publication_Date` LIKE '%$search_name%' 
                ORDER BY `ISBN` DESC";
              

                $result = mysqli_query($con, $query);

                // Return the number of rows in result set
                $rowcount=mysqli_num_rows($result);

                if ( $rowcount==0) {
                  echo " <div class=\"no-books-found\"> No Books Found </div>";
                }

                while($row = mysqli_fetch_array($result))
                {
          ?>
                  <form method="post">
                  <table class="edit-book">

                      <tr>
                          <td>ISBN</td>
                          <input type="hidden" name="old_isbn" value="<?php echo $row['ISBN'] ?>">
                          <td>:</td>
                          <td><input type="text" name="new_isbn" placeholder="ISBN" minlength="9" maxlength="9" value="<?php echo $row['ISBN'] ?>" required></td>

                          <td>GENRE</td>
                          <td>:</td>
                          <td>
                          <select name="genre" required>
                              <option value="">Please select genre</option>

                              <option value="Fantasy"
                              
                              <?php if($row['Genre'] == "Fantasy"){ ?> 
                              selected="selected"
                              <?php } ?> 

                              >Fantasy</option>

                              <option value="Romance"
                              
                              <?php if($row['Genre'] == "Romance"){ ?> 
                              selected="selected"
                              <?php } ?> 
                              
                              >Romance</option>

                              <option value="Academic"
                              
                              <?php if($row['Genre'] == "Academic"){ ?> 
                              selected="selected"
                              <?php } ?> 
                              
                              >Academic</option>

                              <option value="Horror"
                              
                              <?php if($row['Genre'] == "Horror"){ ?> 
                              selected="selected"
                              <?php } ?> 
                              
                              >Horror</option>

                              <option value="Sci-Fi"
                              
                              <?php if($row['Genre'] == "Sci-Fi"){ ?> 
                              selected="selected"
                              <?php } ?> 
                              
                              >Sci-Fi</option>

                              <option value="Motivational"
                              
                              <?php if($row['Genre'] == "Motivational"){ ?> 
                              selected="selected"
                              <?php } ?> 
                              
                              >Motivational</option>

                              <option value="Healthy"
                              
                              <?php if($row['Genre'] == "Healthy"){ ?> 
                              selected="selected"
                              <?php } ?> 
                              
                              >Healthy</option>

                              <option value="History"
                              
                              <?php if($row['Genre'] == "History"){ ?> 
                              selected="selected"
                              <?php } ?> 
                              
                              >History</option>

                              <option value="Kids"
                              
                              <?php if($row['Genre'] == "Kids"){ ?> 
                              selected="selected"
                              <?php } ?> 
                              
                              >Kids</option>
                          </select>
                          </td>
                      </tr>

                      <tr>
                          <td>PRICE</td>
                          <td>:</td>
                          <td><input type="number" name="price" placeholder="Price" min="30" max="500" step="0.01" value=<?php echo $row['Price'] ?> required></td>

                          <td>PAGES</td>
                          <td>:</td>
                          <td><input type="number" name="pages" placeholder="Pages" min="30" max="500" value=<?php echo $row['Pages'] ?> required></td>
                      </tr>

                      <tr>
                          <td>TITLE</td>
                          <td>:</td>
                          <td><input type="text" name="title" placeholder="Title" minlength="3" value="<?php echo $row['Title'] ?>"   required></td>


                          <td>FORMAT</td>
                          <td>:</td>
                          <td>
                          <select name="format" required>
                              <option value="">Please select format</option>
                              <option value="Paper Bag"
                              
                              <?php if($row['Format'] == "Paper Bag"){ ?> 
                              selected="selected"
                              <?php } ?> 
                              
                              >Paper Bag</option>

                              <option value="Hardcover"
                              
                              <?php if($row['Format'] == "Hardcover"){ ?> 
                              selected="selected"
                              <?php } ?> 
                              
                              >Hardcover</option>
                          </select>
                          </td>
                      </tr>

                      <tr>
                          <td>AUTHOR</td>
                          <td>:</td>
                          <td><input type="text" name="author" placeholder="Author"  minlength="3" value="<?php echo $row['Author'] ?>" required></td>

                          <td>PUBLICATION DATE</td>
                          <td>:</td>
                          <td><input type="date" name="date" placeholder="DD/MM/YYYY" value=<?php echo $row['Publication_Date'] ?> required></td>
                      </tr>

                      <tr>
                          <td>LANGUAGE</td>
                          <td>:</td>
                          <td>          
                          <select name="language" required>
                              <option value="">Please select language</option>
                              <option value="English"
                              
                              <?php if($row['Language'] == "English"){ ?> 
                              selected="selected"
                              <?php } ?> 
                              
                              >English</option>

                              <option value="Chinese"
                              
                              <?php if($row['Language'] == "Chinese"){ ?> 
                              selected="selected"
                              <?php } ?> 
                              
                              >Chinese</option>

                              <option value="Malay"
                              
                              <?php if($row['Language'] == "Malay"){ ?> 
                              selected="selected"
                              <?php } ?> 
                              
                              >Malay</option>

                              <option value="Tamil"
                              
                              <?php if($row['Language'] == "Tamil"){ ?> 
                              selected="selected"
                              <?php } ?> 
                              
                              >Tamil</option>
                          </select>
                          </td>

                          <td>QUANTITY AVAILABLE</td>
                          <td>:</td>
                          <td><input type="number" name="qty" placeholder="Quantity" min="10" max="500" value=<?php echo $row['Quantity_Available'] ?> required></td>
                      </tr>

                      <tr>
                          <td>BOOK SUMMARY</td>
                          <td>:</td>
                          <td><textarea name="summary" placeholder="Summary" minlength="10" required><?php echo $row['Summary'] ?></textarea></td>

                          <td>BOOK COVER</td>
                          <td>:</td>
                          <td><textarea name="cover" placeholder="url" minlength="5" required><?php echo $row['Cover'] ?></textarea></td>

                  </table>
                      
                    <div class="edit-btns">
                      <button type="submit" class="gold-btn" name="update-book">UPDATE</button>
                      <button type="submit" class="gold-btn" name="delete-book" >DELETE</button>
                    </div>
                          
                  </form>
            <?php
                }
              }
            mysqli_close($con);
            ?>
        </div>
        <hr>

    </section>



    <!--------------------------------Footer-------------------------------->
    <section class="footer">

      <div class="footer-title">
        <h1>About us</h1>
        <p>This is what we are</p>
      </div>

      <div class="row">
          <div class="footer-col">
            <i class="fas fa-book-reader"></i>
            <h3>Value</h3>
            <p>This online bookstore is mainly about providing the best experience to customers when they visit our website as if they were in the physical bookstore, but online!<br>It provides convenience to people who still need physical books during the lockdown of the country.</p>
          </div>
          <div class="footer-col">
            <i class="fas fa-box-open"></i>
            <h3>Product</h3>
            <p>There are plenty of user-friendly features such as a handy navigation bar, shopping cart as well as help and support section.<br>Everyone is allowed to visit our website to find books they are interested in, but in order to buy them, they would have to register.<br>There will also be special discounts and promotions exclusive to members which customers could register to become one.</p>
          </div>
          <div class="footer-col">
            <i class="fas fa-truck"></i>
            <h3>Service</h3>
            <p>All purchased books will be delivered to the customers' location on time with our professional and trusted delivery service.<br>We also include 24/7 customer support to help customers with their issues!</p>
          </div>
      </div>

      <div class="footer-icon">
        <a href="https://www.facebook.com/profile.php?id=100060182020609" target="_blank"><i class="fab fa-facebook-square"></i></a>
        <a href="https://www.instagram.com/storyglory_my/" target="blank"><i class="fab fa-instagram"></i></a>
        <p>Kindly contact us if you require any assistance.</p>
      </div>
      
    </section>
  </body>
  <script type="text/javascript" src="script.js"></script>

</html>