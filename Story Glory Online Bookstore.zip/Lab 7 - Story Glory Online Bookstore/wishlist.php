<?php
include('session.php');
include('conn.php');

if(isset($_POST['wish-add-cart']))
{
  include("conn.php");

  $Cus_ID = $_POST['Cus_ID'];
  $Book_ID = $_POST['Book_ID'];
  $Quantity = 1;
  $Subtotal = $_POST['Price'];

  // check if cus already have shopping cart
  $cart_sql = "SELECT Cus_ID FROM shopping_cart WHERE Cus_ID = '$Cus_ID'";
  $cart_result = mysqli_query($con,$cart_sql);

  // if no shopping cart
  if(mysqli_num_rows($cart_result) == 0){

    // add shopping_cart
    $add_cart_sql = "INSERT INTO `shopping_cart`
    (Cus_ID) VALUES ($Cus_ID)";

    $add_cart = mysqli_query($con,$add_cart_sql);

  }

  // get cart id to insert into cart item table
  $get_cart_id = "SELECT Cart_ID FROM shopping_cart WHERE Cus_ID = '$Cus_ID'";
  $cart_id_result = mysqli_query($con, $get_cart_id);
  $cart_id = mysqli_fetch_array($cart_id_result);
  $Cart_ID = $cart_id['Cart_ID'];

  $insert_item_sql="INSERT INTO `shopping_cart_item` (
    `Cart_ID`, `Book_ID`, `Quantity` , `Subtotal`)
    VALUES
    ('$Cart_ID', '$Book_ID', '$Quantity', '$Subtotal')";

  $insert_item = mysqli_query($con,$insert_item_sql);
  
  // update total price in shopping cart

  // calc total price
  $total_price_sql = "SELECT shopping_cart.Cus_ID, ROUND(SUM(shopping_cart_item.Subtotal),2) AS Total
  FROM shopping_cart
  INNER JOIN shopping_cart_item ON shopping_cart.Cart_ID = shopping_cart_item.Cart_ID
  WHERE shopping_cart.Cus_ID = '$Cus_ID'
  GROUP BY shopping_cart.Cart_ID";

  $cal_total_price = mysqli_query($con,$total_price_sql);
  $total_price = mysqli_fetch_array($cal_total_price);

  $Total_Price = $total_price['Total'];

  $update_sql = "UPDATE shopping_cart SET
  Total_Price = '$Total_Price'
  WHERE Cus_ID = $Cus_ID";

  $update = mysqli_query($con, $update_sql);

  // delete book from wishlist
  $del_book_sql = "DELETE FROM wishlist WHERE Book_ID = $Book_ID AND Cus_ID = $Cus_ID";

  if(mysqli_query($con, $del_book_sql)) {
      mysqli_close($con);
      echo '<script>
      alert("Successfully Added To Cart!");
      </script>';
  }

}else if(isset($_POST['delete-wish'])){

  include("conn.php");

  $Cus_ID = $_POST['Cus_ID'];
  $Book_ID = $_POST['Book_ID'];

  // delete book from wishlist
  $del_book_sql = "DELETE FROM wishlist WHERE Book_ID = $Book_ID AND Cus_ID = $Cus_ID";

  if(mysqli_query($con, $del_book_sql)) {
      mysqli_close($con);
      echo '<script>
      alert("Successfully Deleted");
      </script>';
  }
}

?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Wishlist - Story Glory</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css"/>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;600;700&display=swap" rel="stylesheet">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  </head>

  <body>
    <!--------------------------------Header-------------------------------->
    <section class="mini-header">

      <nav>
        <a href="home.php"><img src="images/logo.png"></a>
        <div class="search_logo">
          <a href="category.php?page=1&sort=&genre=&valueToSearch="><i class="fas fa-search"> Search for a book!</i></a>
        </div>
        <ul>
          <input id="adminvalue" type="hidden" value="<?php echo $checkAdmin; ?>">
          <li id="adminbutton"><a href="admin.php"><i class="fas fa-user-cog"></i> Admin</a></li>
          <li><a href="home.php"><i class="fas fa-igloo"></i> Home</a></li>
          <li><a href="category.php?page=1&sort=&genre=&valueToSearch="><i class="fas fa-layer-group"></i> Category</a></li>
          <li><a href="wishlist.php"><i class="fab fa-gratipay"></i> My Wishlist</a></li>
          <li><a href="Shopping_Cart.php"><i class="fas fa-shopping-cart"></i> Shopping Cart</a></li>
          <li><a href="MyPurchase.php"><i class="fas fa-shopping-bag"></i> My Purchase</a></li>
          <li><a href="account.php"><i class="fas fa-user-ninja"></i> My profile</a></li>
          <li class="logout" id="logout_btn"><a href="logout.php">Log Out</a></li>
        </ul>
      </nav>

      <h1>My Wish List</h1>

    </section>

    <!--------------------------------wishlist------------------------------->

    <section class="wishlist">

      <?php
        include("conn.php");

        if(isset($cus_id))
        {
          $query = "SELECT * , wishlist.Cus_ID
          FROM book
          INNER JOIN wishlist ON wishlist.Book_ID = book.ISBN
          INNER JOIN customer ON wishlist.Cus_ID = customer.Cus_ID
          WHERE wishlist.Cus_ID = $cus_id";


          $result = mysqli_query($con, $query);

          // Return the number of rows in result set
          $rowcount=mysqli_num_rows($result);

          if ( $rowcount==0) {
          echo " <div class=\"no-books-found\"> No Books Added </div>";
          }

          while($row = mysqli_fetch_array($result))
          {
      ?>
          <div class="wishlist-col">
            <table class="wishlist-item">
              <tr>
                <td><h3 id="btt" > <?php echo $row['Title']?> </h3></td>
                <td><h3 id="bp" > RM <?php echo $row['Price']?> </h3></td>
                <td>
                    <form method="post">
                      <input type="hidden" name="Cus_ID" value="<?php echo $row['Cus_ID']?>" >
                      <input type="hidden" name="Book_ID" value="<?php echo $row['ISBN']?>" >
                      <input type="hidden" name="Price" value="<?php echo $row['Price']?>" >
                      <button type="submit" class="gold-btn" name="wish-add-cart">Add To Cart</button>
                      <button type="submit" class="wish-special"name="delete-wish"><i class="fas fa-trash"></i></button>
                    </form>
                </td>
                <hr>
              </tr>
            </table>
          </div>

      <?php
          }
        }
      mysqli_close($con);
      ?>
      <hr>
    </section>


    <!--------------------------------Footer-------------------------------->
    <section class="footer">

      <div class="footer-title">
        <h1>About us</h1>
        <p>This is what we are</p>
      </div>

      <div class="row">
          <div class="footer-col">
            <i class="fas fa-book-reader"></i>
            <h3>Value</h3>
            <p>This online bookstore is mainly about providing the best experience to customers when they visit our website as if they were in the physical bookstore, but online!<br>It provides convenience to people who still need physical books during the lockdown of the country.</p>
          </div>
          <div class="footer-col">
            <i class="fas fa-box-open"></i>
            <h3>Product</h3>
            <p>There are plenty of user-friendly features such as a handy navigation bar, shopping cart as well as help and support section.<br>Everyone is allowed to visit our website to find books they are interested in, but in order to buy them, they would have to register.<br>There will also be special discounts and promotions exclusive to members which customers could register to become one.</p>
          </div>
          <div class="footer-col">
            <i class="fas fa-truck"></i>
            <h3>Service</h3>
            <p>All purchased books will be delivered to the customers' location on time with our professional and trusted delivery service.<br>We also include 24/7 customer support to help customers with their issues!</p>
          </div>
      </div>

      <div class="footer-icon">
        <a href="https://www.facebook.com/profile.php?id=100060182020609" target="_blank"><i class="fab fa-facebook-square"></i></a>
        <a href="https://www.instagram.com/storyglory_my/" target="blank"><i class="fab fa-instagram"></i></a>
        <p>Kindly contact us if you require any assistance.</p>
      </div>

    </section>
  </body>
  <script type="text/javascript" src="script.js"></script>

</html>