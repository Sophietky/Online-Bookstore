<?php
include('session.php');
include('conn.php');

if(isset($_POST['add-wish']))
  {
    include("conn.php");
    $Cus_ID = $_POST['Cus_ID'];
    $Book_ID = $_POST['Book_ID'];

    $sql="INSERT INTO `wishlist` (
    `Cus_ID`, `Book_ID`)
    VALUES
    ('$Cus_ID', '$Book_ID')";

    if(mysqli_query($con, $sql)) {
      mysqli_close($con);
      echo '<script>
      alert("Successfully Added To Wishlist!");
      </script>';
    }
  }else
  if(isset($_POST['add-book-to-cart']))
  {
    include("conn.php");

    $Cus_ID = $_POST['Cus_ID'];
    $Book_ID = $_POST['Book_ID'];
    $Quantity = intval($_POST['quantity']);
    $Price = intval($_POST['Price']);
    $Subtotal = intval($Quantity * $Price);

    // check if cus already have shopping cart
    $cart_sql = "SELECT Cus_ID FROM shopping_cart WHERE Cus_ID = '$Cus_ID'";
    $cart_result = mysqli_query($con,$cart_sql);

    // if no shopping cart
    if(mysqli_num_rows($cart_result) == 0){

      // add shopping_cart
      $add_cart_sql = "INSERT INTO `shopping_cart`
      (Cus_ID) VALUES ($Cus_ID)";

      $add_cart = mysqli_query($con,$add_cart_sql);

    }

    // get cart id to insert into cart item table
    $get_cart_id = "SELECT Cart_ID FROM shopping_cart WHERE Cus_ID = '$Cus_ID'";
    $cart_id_result = mysqli_query($con, $get_cart_id);
    $cart_id = mysqli_fetch_array($cart_id_result);
    $Cart_ID = $cart_id['Cart_ID'];

    $insert_item_sql="INSERT INTO `shopping_cart_item` (
      `Cart_ID`, `Book_ID`, `Quantity` , `Subtotal`)
      VALUES
      ('$Cart_ID', '$Book_ID', '$Quantity', '$Subtotal')";

    $insert_item = mysqli_query($con,$insert_item_sql);
    
    // update total price in shopping cart

    // calc total price
    $total_price_sql = "SELECT shopping_cart.Cus_ID, ROUND(SUM(shopping_cart_item.Subtotal),2) AS Total
    FROM shopping_cart
    INNER JOIN shopping_cart_item ON shopping_cart.Cart_ID = shopping_cart_item.Cart_ID
    WHERE shopping_cart.Cus_ID = '$Cus_ID'
    GROUP BY shopping_cart.Cart_ID";

    $cal_total_price = mysqli_query($con,$total_price_sql);
    $total_price = mysqli_fetch_array($cal_total_price);

    $Total_Price = $total_price['Total'];

    $update_sql = "UPDATE shopping_cart SET
    Total_Price = '$Total_Price'
    WHERE Cus_ID = $Cus_ID";

    if(mysqli_query($con, $update_sql)) {
        mysqli_close($con);
        echo '<script>
        alert("Successfully Added To Cart!");
        </script>';
    }
}
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Book Details - Story Glory</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css"/>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;600;700&display=swap" rel="stylesheet">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  </head>

  <body>
    <!--------------------------------Header-------------------------------->
    <section class="mini-header">

      <nav>
        <a href="home.php"><img src="images/logo.png"></a>
        <div class="search_logo">
          <a href="category.php?page=1&sort=&genre=&valueToSearch="><i class="fas fa-search"> Search for a book!</i></a>
        </div>
        <ul>
          <input id="adminvalue" type="hidden" value="<?php echo $checkAdmin; ?>">
          <li id="adminbutton"><a href="admin.php"><i class="fas fa-user-cog"></i> Admin</a></li>
          <li><a href="home.php"><i class="fas fa-igloo"></i> Home</a></li>
          <li><a href="category.php?page=1&sort=&genre=&valueToSearch="><i class="fas fa-layer-group"></i> Category</a></li>
          <li><a href="wishlist.php"><i class="fab fa-gratipay"></i> My Wishlist</a></li>
          <li><a href="Shopping_Cart.php"><i class="fas fa-shopping-cart"></i> Shopping Cart</a></li>
          <li><a href="MyPurchase.php"><i class="fas fa-shopping-bag"></i> My Purchase</a></li>
          <li><a href="account.php"><i class="fas fa-user-ninja"></i> My profile</a></li>
          <li class="logout" id="logout_btn"><a href="logout.php">Log Out</a></li>
        </ul>
      </nav>

      <h1>Book Details</h1>

    </section>

    <!--------------------------------Product-------------------------------->
    <?php

    include("conn.php");

    if(isset($cus_id))
    {
      $Book_ID = $_GET["isbn"];

      $sql = "SELECT * 
      FROM `book`, `customer`
      WHERE ISBN = '$Book_ID' AND Cus_ID = '$cus_id'";

      $result = mysqli_query($con, $sql);

      while($row = mysqli_fetch_array($result))
      {
    ?>

    <section class="product">
      
    <!--------------------------------left-------------------------------->
      <form method="post">
        <input type="hidden" name="Cus_ID" value="<?php echo $row['Cus_ID']?>" >
        <input type="hidden" name="Book_ID" value="<?php echo $row['ISBN']?>" >
        <input type="hidden" name="Price" value="<?php echo $row['Price']?>" >

        <div class="row">
          <div class="product-pic">
            <img class="book-cover" src="<?php echo $row['Cover']?>">

            <div class="book-details">
              <h2>Book Details</h2>

              <div class="detail-box">
                <h5>ISBN</h5>
                <i class="fas fa-passport"></i>
                <h6> <?php echo $row['ISBN']?> </h6>
              </div>

              <div class="detail-box">
                <h5>Language</h5>
                <i class="fas fa-globe-asia"></i>
                <h6> <?php echo $row['Language']?> </h6>
              </div>

              <div class="detail-box">
                <h5>Genre</h5>
                <i class="fab fa-buromobelexperte"></i>
                <h6> <?php echo $row['Genre']?> </h6>
              </div>

              <div class="detail-box">
                <h5>Pages</h5>
                <i class="fas fa-scroll"></i>
                <h6> <?php echo $row['Pages']?> pages</h6>
              </div>

              <div class="detail-box">
                <h5>Format</h5>
                <i class="fas fa-book"></i>
                <h6> <?php echo $row['Format']?> </h6>
              </div>

              <div class="detail-box">
                <h5>Publication Date</h5>
                <i class="fas fa-calendar-alt"></i>
                <h6> <?php echo $row['Publication_Date']?> </h6>
              </div>

            </div>

          </div>

    <!--------------------------------Right-------------------------------->

          <div class="add-info">

            <div class="title-box">
              <h1> <?php echo $row['Title']?> </h1>

            <?php 
              $book_rating_sql = "SELECT ROUND(AVG(Rating), 1) As Rating
              FROM `feedback`
              WHERE Book_ID = '$Book_ID'";
              $book_rating_result = mysqli_query($con, $book_rating_sql);
              $book_rating_handle = mysqli_fetch_array($book_rating_result);
              $book_rating = floatval($book_rating_handle['Rating']);

            ?>
            <div class="show-rating">
            <?php
              if($book_rating <= 1 ){
                echo '<i class="fas fa-star"></i>
                <i class="far fa-star"></i>
                <i class="far fa-star"></i>
                <i class="far fa-star"></i>
                <i class="far fa-star"></i>';
              }else
              if($book_rating > 1 ){
                echo '<i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="far fa-star"></i>
                <i class="far fa-star"></i>
                <i class="far fa-star"></i>';
              }else
              if($book_rating > 2 ){
                echo '<i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="far fa-star"></i>
                <i class="far fa-star"></i>';
              }else
              if($book_rating > 3 ){
                echo '<i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="far fa-star"></i>';
              }else
              if($book_rating > 4 ){
                echo '<i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>';
              }
              ?>
              <h6> <?php echo $book_rating; ?> </h6>
            </div>

            <p>By <?php echo $row['Author']?> (Author)</p>
            <p> <?php echo $row['Format']?>  |  <?php echo $row['Genre']?> </p>
            <hr>
            
            <div class="product-col">
              <h2>RM  <?php echo $row['Price']?> </h2>
              <button type="submit" name="add-wish" class="gold-btn">Add To Wish List</button>
            </div>

            <div class="product-col">
              <span><strong>Quantity:</strong><input type="number" name="quantity" min="1" required></span>
              <button type="submit" name="add-book-to-cart" class="gold-btn">Add To Shopping Cart</button>
            </div><br><hr>

            <p class="summary">
              <br>
              <?php echo $row['Summary']?> 
              <br><br>
            </p><hr>
    <?php
      }
    }
    ?>
              <h2>Book Reviews</h2>

    <?php
        include("conn.php");

        $Book_ID = $_GET["isbn"];
    
        if(isset($Book_ID))
        {
          $sql = "SELECT customer.Name, feedback.*
          FROM feedback
          INNER JOIN customer ON customer.Cus_ID = feedback.Cus_ID
          WHERE feedback.Book_ID = '$Book_ID'";
    
          $result = mysqli_query($con, $sql);

          $rowcount=mysqli_num_rows($result);

          if ( $rowcount==0) {
          echo " <div class=\"no-books-found\"> No Feedback Provided </div>";
          }

          while($row = mysqli_fetch_array($result))
          {
    ?>
                <div class="book-review">
                  <h3> <?php echo $row['Name']?> </h3>

                  <?php

                    $rating = intval($row['Rating']);
                    if($rating == 1 ){
                      echo '<i class="fas fa-star"></i>
                      <i class="far fa-star"></i>
                      <i class="far fa-star"></i>
                      <i class="far fa-star"></i>
                      <i class="far fa-star"></i>';
                    }else
                    if($rating == 2 ){
                      echo '<i class="fas fa-star"></i>
                      <i class="fas fa-star"></i>
                      <i class="far fa-star"></i>
                      <i class="far fa-star"></i>
                      <i class="far fa-star"></i>';
                    }else
                    if($rating == 3 ){
                      echo '<i class="fas fa-star"></i>
                      <i class="fas fa-star"></i>
                      <i class="fas fa-star"></i>
                      <i class="far fa-star"></i>
                      <i class="far fa-star"></i>';
                    }else
                    if($rating == 4 ){
                      echo '<i class="fas fa-star"></i>
                      <i class="fas fa-star"></i>
                      <i class="fas fa-star"></i>
                      <i class="fas fa-star"></i>
                      <i class="far fa-star"></i>';
                    }else
                    if($rating == 5 ){
                      echo '<i class="fas fa-star"></i>
                      <i class="fas fa-star"></i>
                      <i class="fas fa-star"></i>
                      <i class="fas fa-star"></i>
                      <i class="fas fa-star"></i>';
                    }
                  ?>

                  <p> <?php echo $row['Feedback']?> </p>
                </div>
    <?php
      }
    }
    ?>

          </div>

        </div>

      </div>
      </form>
    </section>


    <!--------------------------------Footer-------------------------------->
    <section class="footer">

      <div class="footer-title">
        <h1>About us</h1>
        <p>This is what we are</p>
      </div>

      <div class="row">
          <div class="footer-col">
            <i class="fas fa-book-reader"></i>
            <h3>Value</h3>
            <p>This online bookstore is mainly about providing the best experience to customers when they visit our website as if they were in the physical bookstore, but online!<br>It provides convenience to people who still need physical books during the lockdown of the country.</p>
          </div>
          <div class="footer-col">
            <i class="fas fa-box-open"></i>
            <h3>Product</h3>
            <p>There are plenty of user-friendly features such as a handy navigation bar, shopping cart as well as help and support section.<br>Everyone is allowed to visit our website to find books they are interested in, but in order to buy them, they would have to register.<br>There will also be special discounts and promotions exclusive to members which customers could register to become one.</p>
          </div>
          <div class="footer-col">
            <i class="fas fa-truck"></i>
            <h3>Service</h3>
            <p>All purchased books will be delivered to the customers' location on time with our professional and trusted delivery service.<br>We also include 24/7 customer support to help customers with their issues!</p>
          </div>
      </div>

      <div class="footer-icon">
        <a href="https://www.facebook.com/profile.php?id=100060182020609" target="_blank"><i class="fab fa-facebook-square"></i></a>
        <a href="https://www.instagram.com/storyglory_my/" target="blank"><i class="fab fa-instagram"></i></a>
        <p>Kindly contact us if you require any assistance.</p>
      </div>
      
    </section>
  </body>
  <script type="text/javascript" src="script.js"></script>
</html>
