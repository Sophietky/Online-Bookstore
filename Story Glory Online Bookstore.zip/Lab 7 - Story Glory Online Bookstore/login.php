<?php
   include("conn.php");
   session_start();
   $error = "";
   
   if($_SERVER["REQUEST_METHOD"] == "POST") {
      // username and password sent from form 
      
      $myusername = mysqli_real_escape_string($con,$_POST['username']);
      $mypassword = mysqli_real_escape_string($con,$_POST['password']); 
      
      $sql = "SELECT Cus_ID FROM customer WHERE Name = '$myusername' and Password = '$mypassword'";
      $result = mysqli_query($con,$sql);
      $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
      
      $count = mysqli_num_rows($result);
      
      // If result matched $myusername and $mypassword, table row must be 1 row
	
      if($count == 1) {
         $_SESSION['login_user'] = $myusername;
         
         header("location: home.php");
      }else {
         $error = "Your Login Name or Password is invalid";
      }
      if(isset($_POST['reset-btn'])) {
         $error = "";
      }
   }
?>

<html>
   
   <head>
      <title>Login Page</title>
      <title>Create account</title>
      <link rel="stylesheet" href="style.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css"/>
      <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;600;700&display=swap" rel="stylesheet">
   </head>
   
   <body>
   <div class="header">
   <form action = "" method = "post">
      <section class="login_container">

         <h1>Login</h1>
               
         <div>
            Username:
            <input type = "text" name = "username" class = "box">
         </div>

         <div>
            Password:
            <input type = "password" name = "password" class = "box">
         </div>

         <div class="error_msg" id="error_msg"><?php echo $error; ?></div>

         <div class="buttons">
            <button class="white-btn" type="submit">Login</button>
            <button class="reset-btn" id="reset-btn" name="reset-btn" type="reset">Reset</button>
         </div>

         <div class="create_link">
            Don't have an account?
            <p><a href="create_account.html">Create one now!</a></p>
         </div>

      </section>
   </form>
   </div>

   </body>
</html>