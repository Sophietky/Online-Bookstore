<?php
   include('conn.php');

   if(!isset($_SESSION)){
      session_start();
   }

   $username = $_SESSION['login_user'];
   
   $ses_sql = mysqli_query($con,"select * from customer where Name = '$username' ");
   
   $row = mysqli_fetch_array($ses_sql,MYSQLI_ASSOC);

   $cus_id = $row['Cus_ID'];
   $_SESSION['login_user_id'] = $cus_id;

   $login_session = $row['Name'];
   $adminmsg = "";

   $checkAdmin = $row['Admin'];

   if(!isset($_SESSION['login_user'])){
      header("location:login.php");
      die();
   }
?>
