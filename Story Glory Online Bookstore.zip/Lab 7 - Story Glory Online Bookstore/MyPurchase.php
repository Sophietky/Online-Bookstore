<?php
include('conn.php');
include('session.php');

//Button Received
if(isset($_POST['received'])){
  $order = $_POST['order_id'];
  $received_query = "UPDATE `order` SET `Delivery_status`= 'Delivered' WHERE Order_ID = '$order'";

  if ($received_result = mysqli_query($con, $received_query)){
    echo '<script>
    alert("Thank you for shopping with us!");
    </script>'; }else{
      echo '<script>
      alert("There was an error, please try again");
      </script>';
  }
}

// Button Canceled
if(isset($_POST['cancel'])){
  $order = $_POST['order_id'];
  $sql = "SELECT * FROM `order` WHERE Order_ID = '$order'";
  $result = mysqli_query($con, $sql);
  $row = mysqli_fetch_array($result);
  $delivery_status = $row['Delivery_status'];
  
  if ($delivery_status == 'Returned' OR $delivery_status == 'Unsuccessful Delivery'){
    $cancel_sql = "UPDATE `order` SET `Delivery_status` = 'Canceled' WHERE Order_ID = '$order'";
    $cancel_result = mysqli_query($con, $cancel_sql);
    echo '<script>
    alert("Your order has been canceled");
    </script>';
  }else
  {
    echo '<script>
    alert("Some issue occured!");
    </script>';
  }
}

?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Story Glory</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css"/>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;600;700&display=swap" rel="stylesheet">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  </head>

  <body>
    <!--------------------------------Mini Header-------------------------------->
    <section class="mini-header">

      <nav>
        <a href="home.php"><img src="images/logo.png"></a>
        <div class="search_logo">
          <a href="category.php?page=1&sort=&genre=&valueToSearch="><i class="fas fa-search"> Search for a book!</i></a>
        </div>
        <ul>
          <input id="adminvalue" type="hidden" value="<?php echo $checkAdmin; ?>">
          <li id="adminbutton"><a href="admin.php"><i class="fas fa-user-cog"></i> Admin</a></li>
          <li><a href="home.php"><i class="fas fa-igloo"></i> Home</a></li>
          <li><a href="category.php?page=1&sort=&genre=&valueToSearch="><i class="fas fa-layer-group"></i> Category</a></li>
          <li><a href="wishlist.php"><i class="fab fa-gratipay"></i> My Wishlist</a></li>
          <li><a href="Shopping_Cart.php"><i class="fas fa-shopping-cart"></i> Shopping Cart</a></li>
          <li><a href="MyPurchase.php"><i class="fas fa-shopping-bag"></i> My Purchase</a></li>
          <li><a href="account.php"><i class="fas fa-user-ninja"></i> My profile</a></li>
          <li class="logout" id="logout_btn"><a href="logout.php">Log Out</a></li>
        </ul>
      </nav>

        <h1>My &nbsp Purchase</h1>

    </section>

<!--------------------------------My Purchase-------------------------------->
  <form method="POST">
  <div class='purchase-box'>
    <div class="purchase-header">
        <div class="Purchase-User">
              <i class="fas fa-user-circle"></i>
              <p><?php echo $login_session; ?></p>
        </div>
    </div>
    <?php

    $sql = "SELECT * FROM `order`
    INNER JOIN customer ON `order`.Cus_ID = customer.Cus_ID
    WHERE `order`.Cus_ID = '$cus_id'";
    
    $result = mysqli_query($con, $sql);

    // Return the number of rows in result set
    $rowcount=mysqli_num_rows($result);

    if ( $rowcount==0) {
      echo "<div class='purchase-box'>";
      echo "<div class='purchase-header'>";
      echo "<div class='Purchase-status'>";
      echo "<p>Delivery Status</p>";
      echo "</div>";
      echo "</div>";
      echo "<hr>";
      echo "<br>";
      echo "<div class=\"no-books-found\"> No Purchase </div>";

    }else{
      echo "";
    
    //get order based on customer id
    while($order_row = mysqli_fetch_array($result))
    {
      
    ?>
    
    <div class="purchase-header">
      <div class="Purchase-status">
        <p>Delivery Status</p>
        <p style="color:red; font-size: 20px;"><?php echo $order_row['Delivery_status']; ?></p>
      </div>
    </div>
    <hr>
    <br>

    <?php
      $order_id = $order_row['Order_ID'];
      $get_order_item_sql = "SELECT * FROM `order_details` WHERE Order_ID = '$order_id'";
      $get_order_item_result = mysqli_query($con, $get_order_item_sql);
      //get order details based on order id
      while($item_row = mysqli_fetch_array($get_order_item_result))
      {
        $order_item_id = $item_row['Order_Item_ID'];
        $item_details_sql = "SELECT * FROM `order_details`
          INNER JOIN book ON order_details.Book_ID = book.ISBN
          WHERE Order_Item_ID = '$order_item_id'";
        $item_details_result = mysqli_query($con, $item_details_sql);
        //get book details based on order item id
        while($item_details_row = mysqli_fetch_array($item_details_result))
        {
          $item_result = '
            <div class="purchase-item">
            <img src="'. $item_details_row['Cover'] .'">
            <div class="purchase-text">
              <p class="purchase_title">'. $item_details_row['Title'] .'</p>
                <div class="purchase-price">
                  <p>x '. $item_details_row['Quantity'] .'</p>
                  <p>'. $item_details_row['Subtotal'] .'</p>
                </div>
                <div class="purchase-feedback-btn">
                  <a href="feedback.php?isbn='.$item_details_row['Book_ID'].'">Feedback</a>
                </div>
            </div>
            </div>
            <hr>
            <br>
          ';
          echo $item_result;
        }
      }
        ?>
      
      <input type="hidden" name="order_id" value="<?php echo $order_id ?>">
      <div class="order-text">
        <h1 style="margin-right: 60px;">Order Total: </h1>
        <h1><?php echo $order_row['Total_Price']; ?></h1>
      </div>
  
      <div class="purchase-btn">
        <a href="home.php"><button id="special" name="received">Received</button></a>
        <a href="home.php"><button id="special" name="cancel">Cancel Order</button></a>
      </div>
      <br><br><br><br><br><br><br><br><br><br><br><br>
      
      <?php
    }
      }
      mysqli_close($con);
      ?>
      </div>
  </form>

            
    <!--------------------------------Footer-------------------------------->
    
    <section class="footer">

      <div class="footer-title">
        <h1>About us</h1>
        <p>This is what we are</p>
      </div>

      <div class="row">
          <div class="footer-col">
            <i class="fas fa-book-reader"></i>
            <h3>Value</h3>
            <p>This online bookstore is mainly about providing the best experience to customers when they visit our website as if they were in the physical bookstore, but online!<br>It provides convenience to people who still need physical books during the lockdown of the country.</p>
          </div>
          <div class="footer-col">
            <i class="fas fa-box-open"></i>
            <h3>Product</h3>
            <p>There are plenty of user-friendly features such as a handy navigation bar, shopping cart as well as help and support section.<br>Everyone is allowed to visit our website to find books they are interested in, but in order to buy them, they would have to register.<br>There will also be special discounts and promotions exclusive to members which customers could register to become one.</p>
          </div>
          <div class="footer-col">
            <i class="fas fa-truck"></i>
            <h3>Service</h3>
            <p>All purchased books will be delivered to the customers' location on time with our professional and trusted delivery service.<br>We also include 24/7 customer support to help customers with their issues!</p>
          </div>
      </div>

      <div class="footer-icon">
        <a href="https://www.facebook.com/profile.php?id=100060182020609" target="blank"><i class="fab fa-facebook-square"></i></a>
        <a href="https://www.instagram.com/storyglory_my/" target="blank"><i class="fab fa-instagram"></i></a>
        <p>Kindly contact us if you require any assistance.</p>
      </div>
      
    </section>
  </body>
  <script type="text/javascript" src="script.js"></script>
</html>