<?php
include("conn.php");
$sql="INSERT INTO customer (Name, Password, Contact, Email, Subscription, Shipping_Address)
VALUES
('$_POST[username]','$_POST[password]','$_POST[phonenumber]','$_POST[email]','$_POST[subscribe]','$_POST[shipping_address]')";

$check_existing = mysqli_query($con,"SELECT * FROM customer WHERE Name = '$_POST[username]'");
$exist_rows = mysqli_num_rows($check_existing);

if (!$exist_rows == 0) 
{
    echo '<script>alert("Username already taken, please choose another username.");
    window.location.href = "create_account.html";
    </script>';
} 
else 
{
    mysqli_query($con,$sql);
    echo '<script>alert("Details recorded!");
    window.location.href = "create_done.html";
    </script>';
}

mysqli_close($con);
?>