<?php
include('session.php');
include("conn.php");

$sql = "SELECT * 
FROM `shopping_cart`
INNER JOIN `shopping_cart_item` ON shopping_cart.Cart_ID = shopping_cart_item.Cart_ID
INNER JOIN `customer` ON shopping_cart.Cus_ID = customer.Cus_ID
INNER JOIN book ON shopping_cart_item.Book_ID = book.ISBN
WHERE shopping_cart.Cus_ID = '$cus_id'";

$result = mysqli_query($con, $sql);

$row = mysqli_fetch_array($result);

?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Story Glory</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css"/>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;600;700&display=swap" rel="stylesheet">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  </head>

  <body>
    <!--------------------------------Mini Header-------------------------------->
    <section class="mini-header">

      <nav>
        <a href="home.php"><img src="images/logo.png"></a>
        <div class="search_logo">
          <a href="category.php?page=1&sort=&genre=&valueToSearch="><i class="fas fa-search"> Search for a book!</i></a>
        </div>
        <ul>
          <input id="adminvalue" type="hidden" value="<?php echo $checkAdmin; ?>">
          <li id="adminbutton"><a href="admin.php"><i class="fas fa-user-cog"></i> Admin</a></li>
          <li><a href="home.php"><i class="fas fa-igloo"></i> Home</a></li>
          <li><a href="category.php?page=1&sort=&genre=&valueToSearch="><i class="fas fa-layer-group"></i> Category</a></li>
          <li><a href="wishlist.php"><i class="fab fa-gratipay"></i> My Wishlist</a></li>
          <li><a href="Shopping_Cart.php"><i class="fas fa-shopping-cart"></i> Shopping Cart</a></li>
          <li><a href="MyPurchase.php"><i class="fas fa-shopping-bag"></i> My Purchase</a></li>
          <li><a href="account.php"><i class="fas fa-user-ninja"></i> My profile</a></li>
          <li class="logout" id="logout_btn"><a href="logout.php">Log Out</a></li>
        </ul>
      </nav>

        <h1>Shipping &nbsp Details</h1>

    </section>

        <!--------------------------------Shopping Header-------------------------------->

        <div class="shopping-row">
          <div id="progress2"></div>
              <div class="step-col"><small>1. Shopping Cart</small></div>
              <div class="step-col"><small>2. Shipping Details</small></div>
              <div class="step-col"><small>3. Payment Method</small></div>
        </div>

    <!--------------------------------Shipping Details-------------------------------->
    
    <div class="shipping-details">
      <form action="PaymentMethod.php" method="POST">
        <h1>Shipping Details</h1>
        <hr>
        <div class="shipping-box">
          <section class="shipping-left">
            <div class="input-row">
              <div class="input-group">
                <input type="text" placeholder="Full Name" required value="<?php echo $row['Name'] ?>">
              </div>

              <div class="input-group">
                <input type="tel" placeholder="Phone Number" required value="<?php echo $row['Contact'] ?>">
              </div>
            </div>

            <textarea rows="5" placeholder="Address" required><?php echo $row['Shipping_Address'] ?></textarea>
            <input type="hidden" name="Cus_ID" value="<?php echo $row['Cus_ID']?>" >

            <div class="input-row">
              <div class="input-group">
                <input type="number" placeholder="Zip/Postal Code" required>
              </div>

              <div class="input-group">
                <input type="text" placeholder="City" required>
              </div>
            </div>

            <div class="radio-row">
              <div class="shipping-radio">
                <input type="radio" name="deliver_type" id="small" onclick="Standard()" value="Standard Shipping - RM5">
                <label id="Standard" for="small">Standard Shipping - RM5 <br>
                </label>
              </div>
              <div class="shipping-radio">
                <input type="radio" name="deliver_type" id="big" onclick="Next_Day()" checked = "checked" value="Next Day Delivery - RM10">
                <label id="Next_Day" for="big">Next Day Delivery - RM10</label>
              </div>
            </div>
            <hr>
            
            <div class="shipping-btn">
              <button type="submit" value="Next" name="submit" id="submit">Next</button>
              <a href="Shopping_Cart.php"><button type="button" value="Cancel">Cancel</button></a>
            </div>

          </section>

            <section class="shipping-right">
              <div class="container">
                  <h4>Cart <span style="color:black"><i class="fas fa-shopping-cart"></i></span></h4>
                  <hr>
                  <input type="hidden" id="subtotal_hidden" value="<?php echo $row['Total_Price']?>">
                  <p id="subtotal">Subtotal<span>RM<span id="subtotal_amount"><?php echo $row['Total_Price']?></span></span></p>
                  <p>Shipping<span id="Shipping">RM10.00</span></p>
                  <hr>
                  <input type="hidden" name="total_price_hidden" id="total_price_hidden" value="<?php echo $row['Total_Price'] + 10; ?>">
                  <p>Total <span>RM<span class="price" style="color:black" id="total_amount"><b><?php echo $row['Total_Price'] + 10; ?></b></span></span></p>
              </div>
            </section>
        </div>
      </form>
    </div>

    <script>
    var subtotal = document.getElementById("subtotal_hidden").value;
    var subtotal_int = parseFloat(subtotal)
    function Standard() {
      var shipping = parseFloat(5.00)
      document.getElementById("Shipping").innerHTML = "RM5.00";
      var total_price = subtotal_int + shipping;
      document.getElementById("total_amount").innerHTML = total_price;
      document.getElementById("total_price_hidden").value = total_price;
    }

    function Next_Day() {
      var shipping = parseFloat(10.00)
      document.getElementById("Shipping").innerHTML = "RM10.00";
      var total_price = subtotal_int + shipping;
      document.getElementById("total_amount").innerHTML = total_price;
      document.getElementById("total_price_hidden").value = total_price;
    }


    
    </script>

    <!--------------------------------Footer-------------------------------->
    <section class="footer">

      <div class="footer-title">
        <h1>About us</h1>
        <p>This is what we are</p>
      </div>

      <div class="row">
          <div class="footer-col">
            <i class="fas fa-book-reader"></i>
            <h3>Value</h3>
            <p>This online bookstore is mainly about providing the best experience to customers when they visit our website as if they were in the physical bookstore, but online!<br>It provides convenience to people who still need physical books during the lockdown of the country.</p>
          </div>
          <div class="footer-col">
            <i class="fas fa-boxopen"></i>
            <h3>Product</h3>
            <p>There are plenty of user-friendly features such as a handy navigation bar, shopping cart as well as help and support section.<br>Everyone is allowed to visit our website to find books they are interested in, but in order to buy them, they would have to register.<br>There will also be special discounts and promotions exclusive to members which customers could register to become one.</p>
          </div>
          <div class="footer-col">
            <i class="fas fa-truck"></i>
            <h3>Service</h3>
            <p>All purchased books will be delivered to the customers' location on time with our professional and trusted delivery service.<br>We also include 24/7 customer support to help customers with their issues!</p>
          </div>
      </div>

      <div class="footer-icon">
        <a href="https://www.facebook.com/profile.php?id=100060182020609" target="blank"><i class="fab fa-facebook-square"></i></a>
        <a href="https://www.instagram.com/storyglory_my/" target="blank"><i class="fab fa-instagram"></i></a>
        <p>Kindly contact us if you require any assistance.</p>
      </div>
      
    </section>
  </body>
  <script type="text/javascript" src="script.js"></script>

</html>